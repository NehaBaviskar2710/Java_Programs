
class Singleton 
{
    
}
