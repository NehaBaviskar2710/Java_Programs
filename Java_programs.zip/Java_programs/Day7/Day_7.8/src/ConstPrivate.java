class Program
{
    private int real;
    private int imag;

    public Program()
    {
        System.out.println("Inside constructor");
        this.real = 0;
        this.imag = 0;
    }

    public static void test()
    {
        Program p = new Program();
    }
}
class ConstPrivate
{
    public static void main(String[] args)
    {
        //Program p = new Program();
        Program.test();

    }
}