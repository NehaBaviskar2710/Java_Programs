package p1;
public class Complex 
{
    public String toString()
    {  
        return "Complex.toString()";
    }  
}

