class Singleton {
    private Singlwton()
    {

    }
    private static Singleton reference;
    public stati
}
