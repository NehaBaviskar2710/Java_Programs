class Test{
    public void showRecord()
    {
        System.out.println("Display show method");
    }
    public static void printRecord()
    {
        System.out.println("Print method");
    }
}
class StatMethod 
{
    public static void main(String[] args)
    {
        Test t = new Test();
        t.showRecord();

        Test.printRecord();
        t.showRecord();
    }    
}
