
class TComplex 
{
    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "TComplex.toString()";
    }
}
