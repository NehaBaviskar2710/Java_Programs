class Test
{
    public static int num1 = 10;
}
class StaticClass
{
    private static int num2 = 20;
    public static void main(String[] args)
    {
        System.out.println("Num1:" +Test.num1);
        System.out.println("Num2:" +num2);
    }
}