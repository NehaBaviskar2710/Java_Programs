import static java.lang.Math.PI;
class PackageProgram 
{
    public static void main(String[] args)
    {
        double radius = 10.5;
        double area = Math.PI * Math.pow(radius, 2);
        System.out.println("Area of circle:"+area);
    }
    public static void main1(String[] args)
    {
        double radius = 10.5;
        double area = 3.14 * radius * radius;
        System.out.println("Area of circle"+area);
    }    
}
