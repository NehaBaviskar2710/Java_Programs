// class MethodLocalCall
// {
//     public static void printRecord()
//     {
//         int count = 0;
//         count = count+1;
//         System.out.println("Count:"+count);
//     }
//     public static void main(String[] args)
//     {
//         MethodLocalCall.printRecord();
//         MethodLocalCall.printRecord();
//         MethodLocalCall.printRecord();

//     }
// }

class MethodLocalCall
{
    static int count;
    public static void printRecord()
    {
        count = count+1;
        System.out.println("Count:"+count);
    }
    public static void main(String[] args)
    {
        MethodLocalCall.printRecord();
        MethodLocalCall.printRecord();
        MethodLocalCall.printRecord();

    }
}