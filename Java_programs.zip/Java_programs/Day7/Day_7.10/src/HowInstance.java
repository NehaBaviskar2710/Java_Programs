class InstanceCounter
{
    private static int count;
    public static int count;
    public InstanceCounter()
    {
        
    }
}
class HowInstance {
    
}
