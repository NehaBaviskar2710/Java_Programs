class Program
{
    public int num1 =10;
    public static int num2 = 20;
    public static void main(String[] args)
    {
        Program p = new Program();
        System.out.println("Number:"+p.num1);
        System.out.println("Number2:"+Program.num2);
    }
}