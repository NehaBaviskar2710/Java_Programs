class Test
{
    private int num1;
    private int num2;
    private static int num3;

    static 
    {
        Test.num3 = 0;
    }

    public Test()
    {
        this.num1 = 0;
        this.num2 = 0;
    }


    public void setNum1(int num1)
    {
        this.num1 = num1;
    }

    public void setNum2(int num2)
    {
        this.num2 = num2;
    }

    public static void setNum3(int num3)
    {
        Test.num3  = num3;
    }

    public void displayRecord()
    {
        System.out.println("Number1:"+this.num1);
        System.out.println("Number2:"+this.num2);
        System.out.println("Number3:"+Test.num3);

    }

}
class Program 
{
    public static void main(String[] args)
    {
        Test t = new Test();
        t.setNum1(10);
        t.setNum2(20);
        Test.setNum3(30);
        t.displayRecord();

    }    
}
