package org.example.main;

class Task1 implements Runnable
{
	private Thread thread;
	
	public Task1(String name)
	{
		this.thread = new Thread(this, name);
		this.thread.start();
	}
	@Override
	public void run()
	{
		if(this.thread.isDaemon())
			System.out.println(this.thread.getName()+" is Daemon Thread");
		else
			System.out.println(this.thread.getName()+" is User Thread");
	}
}
public class UserDaemon 
{
	public static void main(String[] args)
	{
		Thread thread = Thread.currentThread();
		if(thread.isDaemon())
			System.out.println(thread.getName()+" is Daemon Thread");
		else
			System.out.println(thread.getName()+" is User Thread");
		
		Task1 t1 = new Task1("Thread#1");
	}
}
