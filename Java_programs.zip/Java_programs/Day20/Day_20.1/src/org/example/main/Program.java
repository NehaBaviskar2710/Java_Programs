package org.example.main;

class Task implements Runnable
{
	@Override
	public void run() 
	{
		System.out.println("Inside run method:");
	}
}
public class Program 
{
	public static void main(String[] args)
	{
		Runnable target = new Task();
		Thread th = new Thread(target, "Thread1");
		th.start();
	}
}
