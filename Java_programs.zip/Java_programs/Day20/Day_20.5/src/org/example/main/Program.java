package org.example.main;

class T
public class Program {

}
