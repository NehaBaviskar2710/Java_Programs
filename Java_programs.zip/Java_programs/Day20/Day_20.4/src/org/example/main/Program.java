package org.example.main;

public class Program 
{
	public static void main(String[] args)
	{
		Thread thread = Thread.currentThread();
		thread.setPriority(thread.getPriority()+2);
		System.out.println("Priority of"+thread.getName()+"is "+thread.getPriority());
	}
	public static void main1(String[] args)
	{
		Thread thread = Thread.currentThread();
		int priority = thread.getPriority();
		System.out.println("Priority of threads:"+thread.getName()+"priority");
	}
}
