package org.example.main;

import java.util.Scanner;

import java.util.StringTokenizer;

public class StringTokenizerClass 
{
	public static void main(String[] args)
	{
		String s1 = "Have a nice day";
		StringTokenizerClass stk = new StringTokenizerClass(s1);
		System.out.println("Count Tokens : "+stk.countTokens());
	}
	
	
}
