package org.example.main;

public class StringTwister 
{
	public static void main(String[] args)
	{
		String s1 = new String("Neha");
		String s2 = new String("Neha");
		if(s1.equals(s2))
		{
			System.out.println("Equal");
		}
		else
			System.out.println("Not equal");
	}
	public static void main1(String[] args)
	{
		String s1 = new String("neha");
		String s2 = new String("neha");
		if(s1 == s2)
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}
	}
}
