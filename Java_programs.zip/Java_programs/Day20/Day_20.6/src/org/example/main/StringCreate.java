package org.example.main;

public interface StringCreate 
{
	public static void main(String[] args)
	{
		String s1 = "Neha";
		s1.concat("Baviskar");
		System.out.println(s1);
		
		String s2 = s1.concat("Baviskar");
		System.out.println(s2);
	}
	public static void main2(String[] args)
	{
		String s1 = "Neha";
		String s2 = s1 + "Baviskar";
		System.out.println(s1 == s2);
	}
	public static void main1(String[] args)
	{
		String s1 = "Neha";
		char ch = s1.charAt(1);
		System.out.println(ch);
	}
}
