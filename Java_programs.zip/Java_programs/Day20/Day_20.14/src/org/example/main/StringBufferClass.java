package org.example.main;

public class StringBufferClass 
{
	public static void main(String[] args)
	{
		StringBuffer sb1 = new StringBuffer("Neha");
		StringBuffer sb2 = new StringBuffer("Neha");
		if(sb1 == sb2)
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}
	}
}
