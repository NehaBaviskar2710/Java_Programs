package extra.practice;

class Unboxing
{
//	public static void main(String[] args)
//	{
//		String fruit = new String("Mango");
//		float num1 = Float.parseFloat(fruit);
//		System.out.println("Number:"+num1);
//	}
	public static void main1(String[] args)
	{
		String name = new String("123");
		int number = Integer.parseInt(name);
		System.out.println("Number is:"+number);
	}
}