package extra.practice;

class Boxing 
{
	public static void main(String[] args)
	{
		
	}
	public static void main2(String[] args)
	{
		float salary = 100000f;
		System.out.println("Salary of employee:" +salary);
		String sal = Float.toString(salary);
		System.out.println("Salary in float is:"+sal);
	}
	public static void main1(String[] args)
	{
		int number = 109;
		System.out.println("Number:"+number);
		String str = Integer.toString(number);
		System.out.println("String is:"+str);
	}
}
