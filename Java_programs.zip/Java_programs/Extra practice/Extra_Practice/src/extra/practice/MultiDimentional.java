package extra.practice;

public class MultiDimentional
{
	public static void main(String[] args)
	{
		int[][] arr = new int[][];
		i
	}
}
