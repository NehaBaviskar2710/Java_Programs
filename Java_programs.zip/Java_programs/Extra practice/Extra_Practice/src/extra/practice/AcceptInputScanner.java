package extra.practice;

//import java.util.Scanner;
//class AccpetInputScanner
//{
//	public static void main(String[] args)
//	{
//		Scanner scan = new Scanner(System.in);
//		System.out.print("Accept inputs from user");
//		System.out.print("Name:");
//		String name = scan.nextLine();
//	}
//}
import java.util.Scanner;
class AcceptInputScanner 
 {
	 public static void main(String[] args) 
	 {
		 Scanner sc = new Scanner( System.in );
		 System.out.print("Name : ");
		 String name = sc.nextLine();
		 System.out.print("Empid : ");
		 int empid = sc.nextInt();
		 System.out.print("Salary : ");
		 float salary = sc.nextFloat();
		 System.out.println(name+" "+empid+" "+salary);
	 }
 }
