package extra.practice;

import java.util.Scanner;

public class ArrayDescribe
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array ize:");
		int size = sc.nextInt();
		int arr[] = new int[size];	
	}
	public static void main1(String[] args)
	{
		//Array reference 
		int arr[] = null;
		int[] arr = null;
		
		int arr[] = null;
		int[] arr = null;
		
		////array instance
		int[] arr = null;
		arr = new int[3];
		
		//
		int arr[] = new int[3];
		int arr[] = new int[] {10,20,30};		
	}
}