package extra.practice;

import java.time.LocalTime;
class LocalTimeClass
{
	public static void main(String[] args)
	{
		LocalTime lm = LocalTime.now();
		int hr = lm.getHour();
		int min = lm.getMinute();
		int sec = lm.getSecond();
		System.out.println(hr+":"+min+":"+sec);
	}
}
