package extra.practice;

import java.util.Scanner;
class ThisReference
{
	String name;
	int id;
	float Salary;
	
	public void acceptRecord()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Name:");
		this.name = sc.nextLine();
		System.out.println("Id:");
		this.id = sc.nextInt();
		System.out.println("Salary:");
		this.Salary = sc.nextFloat();
		
	}
	public static void main(String[] args)
	{
		ThisReference t = new ThisReference();
		t.acceptRecord();
	}
}