package extra.practice;

public class CommandLine
{
	public static void main(String[] args)
	{
		System.out.println("Hello," +args[0]);
	}
}