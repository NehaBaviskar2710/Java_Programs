package extra.practice;

import java.time.LocalDate;
import java.util.Scanner;
class Date
{
	int day;
	int month;
	int year;
	Date(int day, int month, int year)
	{
		System.out.println("Inside constructor:");
		LocalDate ld = LocalDate.now();
		this.day = ld.getDayOfMonth();
		this.month = ld.getMonthValue();
		this.year = ld.getYear();
		System.out.println(this.day+" / "+this.month+" / "+this.year);
	}
}
class Constructor
{
	public static void main(String[] args)
	{
		Date d = new Date(18, 2, 2024);
	}
}