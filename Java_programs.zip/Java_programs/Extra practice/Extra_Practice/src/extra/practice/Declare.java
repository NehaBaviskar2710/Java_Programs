package extra.practice;

class Declare
{
	public static void main(String[] args)
	{
		String name;
		name = "Jay";
		System.out.println("Name:"+name);
		name = "Neha";
		System.out.println("Name is:"+name);
	}
	public static void main1(String[] args)
	{
		int number;
		number = 10;
		System.out.println("Number:"+number);
	}
}