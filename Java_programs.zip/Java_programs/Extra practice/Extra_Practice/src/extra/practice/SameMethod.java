package extra.practice;

class SameMethod
{
	public static void sum(int num1, int num2, int num3)
	{
		int result = num1+num2+num3;
		System.out.println("Result:"+result);
	}
	public static void sum(int s1, int s2)
	{
		//int addition = s1+s2;
		//System.out.println("Addition of 2 numbers:"+addition);
	}
	public static void main()
	{
		SameMethod.sum(10, 20, 30);
		SameMethod.sum(50, 60);
	}
}