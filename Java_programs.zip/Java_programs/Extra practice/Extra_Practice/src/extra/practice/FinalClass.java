package extra.practice;

class FinalClass
{
	public static void main(String[] args)
	{
		final int num = 100;
		int num = 19;
		System.out.println("Number is:"+num);
	}
}