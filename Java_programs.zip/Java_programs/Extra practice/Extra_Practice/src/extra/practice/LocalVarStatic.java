package extra.practice;

class Program1
{
	public static void printRecord()
	{
		int count = 0;
		count = count + 1;
		
		System.out.println("Count:"+count);	
	}
}
public class LocalVarStatic
{
	public static void main(String[] args)
	{
		Program1.printRecord();
		Program1.printRecord();
	}
}