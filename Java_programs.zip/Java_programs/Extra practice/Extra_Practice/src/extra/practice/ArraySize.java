package extra.practice;

import java.util.Scanner;
public class ArraySize
{
	public static void main2(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array:");
		int size = sc.nextInt();
		int arr[] = new int[size];
		
	}
	public static void main1(String[] args)
	{
		int arr[];
		int[] arr1;
		int arr2[] = null;
		arr2 = new int[3];
		int arr3[] = new int[3];
		
	}
}