package extra.practice;
import java.util.Scanner;
class Import
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Hello world");
	}
}