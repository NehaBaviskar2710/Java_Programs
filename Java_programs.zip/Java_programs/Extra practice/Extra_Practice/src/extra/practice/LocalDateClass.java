package extra.practice;

import java.time.LocalDate;

class LocalDateClass
{
	public static void main(String[] args)
	{
		LocalDate ld = LocalDate.now();
		System.out.println("Date");
		int date = ld.getDayOfMonth();
		System.out.println("Month:");
		int month = ld.getMonthValue();
		System.out.println("Year:");
		int year = ld.getYear();
		System.out.println(date+" / "+month+" / "+year);
	}
}