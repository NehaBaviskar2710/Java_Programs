package extra.practice;

import java.util.Date;
class DateClass
{
	public static void main(String[] args)
	{
		Date d = new Date();
		System.out.println("day");
		int day = d.getDate();
		System.out.println("Month");
		int month = d.getMonth()+1;
		System.out.println("Year");
		int year = d.getYear()+1900;
		System.out.println(day+" / "+month+" / "+year);
	}
}