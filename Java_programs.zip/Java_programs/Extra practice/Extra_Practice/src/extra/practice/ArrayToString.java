package extra.practice;

import java.util.Arrays;
public class ArrayToString
{
	public static void main(String[] args)
	{
		int arr[] = new int[3];
		System.out.println(Arrays.toString(arr));
	}
}