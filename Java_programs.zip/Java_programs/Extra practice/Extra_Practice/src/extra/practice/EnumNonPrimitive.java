package extra.practice;

enum Day
{
	MON(10), TUES(20), WED(30), THU(40), FRI(50);
}
public class EnumNonPrimitive {

}
