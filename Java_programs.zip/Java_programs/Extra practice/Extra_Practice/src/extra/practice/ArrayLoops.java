package extra.practice;


public class ArrayLoops
{
	public static void main(String[] args)
	{
		int arr[] = new int[3];
		for(int element: arr)
			System.out.println(arr);
	}
	public static void main3(String[] args)
	{
		int arr[] = new int[3];
		for(int index = 0; index<3; index++)
		{
			System.out.println(arr[index]);
		}
	}
	public static void main2(String[] args)
	{
		int arr[] = new int[3];
		int index = 0;
		while(index<3)
		{
			System.out.println(arr[index]);
			index = index+1;
		}
	}
	public static void main1(String[] args)
	{
		
		int arr[] = new int[3];
		int index = 0;
		do {
			System.out.println("arr["+index+"]:"+arr[index]);
			index = index+1;
		}while(index<3);
	}
}