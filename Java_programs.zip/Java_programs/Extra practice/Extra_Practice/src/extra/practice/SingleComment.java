package extra.practice;

class SingleComment
{
	public static void main(String[] args)
	{
		//To write single line comment
		System.out.println("Program for Single line comment");
	}
}
