package extra.practice;

enum Color{
	RED, GREEN, BLUE;
}
public class EnumProgram 
{
	public static void main(String[] args)
	{
		Color[] colors = Color.values();
		for(Color color : colors)
			System.out.println(color.name()+" "+color.ordinal());
	}
	public static void main4(String[] args)
	{
		Color color = Color.RED;
		System.out.println(color.name()+ " "+color.ordinal());
		
		Color color1 = color.GREEN;
		System.out.println(color1.name()+" "+color1.ordinal());
		
		Color color2 = Color.BLUE;
		System.out.println(color2.name()+" "+color2.ordinal());
		
	}
	public static void main3(String[] args)
	{
		System.out.println(Color.BLUE.name());
		System.out.println(Color.BLUE.ordinal());
	}
	public static void main2(String[] args)
	{
		System.out.println(Color.GREEN.name());
		System.out.println(Color.GREEN.ordinal());
		
	}
	public static void main1(String[] args)
	{
		System.out.println(Color.RED.name());
		System.out.println(Color.RED.ordinal());	
	}
}
