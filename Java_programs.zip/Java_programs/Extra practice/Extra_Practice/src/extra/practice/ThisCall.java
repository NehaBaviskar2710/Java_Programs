//package extra.practice;
//
//
//class ThisCall
//{
//	int day, month, year;
//	
//	pubic void getAccept()
//	{
//		this.day = day;
//		this.month = month;
//		this.year= "year";
//	}
//	public static void main(String[] args)
//	{
//		ThisCall th = new ThisCall
//		{
//			th.getAccept();
//			
//	    }
//		
//	}
//}