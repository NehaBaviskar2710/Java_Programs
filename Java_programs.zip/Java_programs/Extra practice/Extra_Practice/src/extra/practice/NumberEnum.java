package extra.practice;

enum Number{
	MON(1), TUES(2), WED(3);
	
	private int dayNumber;
	
	private Number(int dayNumber)
	{
		this.dayNumber = dayNumber;
	}
	public int getDayNumber()
	{
		return dayNumber;
	}
}
public class NumberEnum 
{
	public static void main(String[] args)
	{
		Number n = Number.MON;
		System.out.println(n.name()+" "+n.ordinal());
		
		Number t = Number.TUES;
		System.out.println(t.name()+" "+t.ordinal());
		
		Number W = Number.WED;
		System.out.println(W.name()+" "+W.ordinal());
	}
}
