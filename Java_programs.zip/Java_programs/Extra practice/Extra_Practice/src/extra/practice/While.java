package extra.practice;

public class While
{
	public static void main(String[] args)
	{
		int arr[] = new int[3];
		int index = 0;
		while(index<3)
		{
			System.out.println("Array index:"+index+" : "+arr[index]);
			index = index+1;
		}
	}
}