package extra.practice;

public class DoWhile
{
	public static void main(String[] args)
	{
		int arr[] = new int[3];
		int index = 0;
		do
		{
			System.out.println("Array index:"+index+" "+arr[index]);
			index = index+1;
		}while(index<3);
	}
}