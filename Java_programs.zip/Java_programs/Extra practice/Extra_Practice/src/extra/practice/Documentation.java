package extra.practice;

class Documentation
{
	public static void main(String[] args)
	{
		/**
		 In documentation comment 2 * used
		 documentation comment is used for documentation purpose
		 */
		System.out.println("Documentation comment");
	}
}
