package extra.practice;

public class Stack {

}
