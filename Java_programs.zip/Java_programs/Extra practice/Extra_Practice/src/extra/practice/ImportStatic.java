package extra.practice;

import static java.lang.Math.PI;
import static java.lang.Math.pow;
public class ImportStatic
{
	public static void main(String[] args)
	{
		double rad = 20.3d;
		double area = PI * pow(rad, 2);
		System.out.println("Area : "+area);
	}
}