package extra.practice;

import java.util.Scanner;
public class ArrayPrint
{
	Scanner sc = new Scanner(System.in);
	private static void acceptRecord(int[] arr)
	{
		if(arr!=null)
		{
			for(int index = 0; index<arr.length; index++)
			{
				System.out.println(arr[index]);
			}
		}
	}
	private static void printRecord(int[] arr)
	{
		if(arr!=null)
		{
			if(arr!=null)
			{
				for(int index=0;index<arr.length; index++)
				{
					System.out.println(arr[index]);
				}
			}
		}
	}
	public static void main(String[] args)
	{
		int arr[] = new int[3];
		ArrayPrint.acceptRecord(arr);
		ArrayPrint.printRecord(arr);
	}
}