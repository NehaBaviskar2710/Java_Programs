package extra.practice;

class Same
{
	int day;
	int month;
	int year;
	
}
class DefaultParameterless
{
	public static void main(String[] args)
	{
		Same s = new Same();
		System.out.println("Default parameterless Constructor");
	}
}