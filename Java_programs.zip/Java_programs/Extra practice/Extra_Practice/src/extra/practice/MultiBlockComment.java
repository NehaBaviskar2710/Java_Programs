package extra.practice;

public class MultiBlockComment
{
	public static void main(String[] args)
	{
		/*
		 Multiline comment is also called as Block comment
		 */
		System.out.println("Multi line comment");
	}
}