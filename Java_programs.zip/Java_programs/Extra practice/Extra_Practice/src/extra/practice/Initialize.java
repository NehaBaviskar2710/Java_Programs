package extra.practice;

class Initialize
{
	public void acceptRecord()
	{
		
	}
	public static void main(String[] args)
	{
		Initialize in = null;
		in.acceptRecord();
		
	}
}