package extra.practice;

import java.lang.reflect.Array;

public class ArrayTry
{
	public static void main(String[] args)
	{
		int[] arr = new int[5];
		System.out.println("Array elements:");
		arr[0] = 10;
		arr[1] = 20;
		arr[2] = 30;
		arr[3] = 40;
		arr[4] = 50;
		for(int i: arr)
		{
			System.out.println(i);
		}
	}
	public static void main1(String[] args)
	{
		int[] arr = new int[] {10,20,30,40,50};
		System.out.println("Array elements:");
		for(int index =  0; index<arr.length; index++)
		{
			System.out.println(arr[index]);
		}
	}
}