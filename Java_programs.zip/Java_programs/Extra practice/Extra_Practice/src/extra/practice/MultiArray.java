//package extra.practice;
//
//import java.util.Scanner;
//class MultiArray
//{
//	private static Scanner sc = new Scanner(System.in);
//	public static void acceptRecord(int[][] arr)
//	{
//		for(int row = 0; row<arr.length; row++)
//		{
//			for(int column=0; column<arr.length; column++)
//			{
//				System.out.println("Enter number:");
//				arr[row][column] = sc.nextInt();
//			}
//		}
//	}
//	
//	public static void printRecord(int[][] arr)
//	{
//		
//	}
//	public static void main(String[] args)
//	{
//		int arr[][] = new int[4][3];
//		MultiArray.acceptRecordRecord(int[][] arr);
//		MultiArray.printRecord(int[][] arr);
//		
//	}
//}