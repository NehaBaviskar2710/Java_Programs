package extra.practice;

import java.util.Arrays;
import java.time.LocalDate;
class Date1
{
	private int day;
	private int month;
	private int year;
	
	public Date1()
	{
		LocalDate ld = LocalDate.now();
		this.day = ld.getDayOfMonth();
		this.month = ld.getMonthValue();
		this.year = ld.getYear();
	}
	
	public Date1(int day, int month, int year)
	{
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	public String toString(arr)
	{
		System.out.println(this.day+" "+this.month+" "+this.year);
	}
	
}
public class ArrayDate
{
	public static void main(String[] args)
	{
		Date1 arr[] = new Date1[3];
		System.out.println(Arrays.toString(arr));
	}
}
