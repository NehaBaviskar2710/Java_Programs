package extra.practice;

class Complex
{
	private static int real;
	private static int imag;
	
//	private Complex(int real, int imag)
//	{
//		this.real = real;
//		this.imag = imag;
//	}
	public static void accept()
	{
		Complex c2 = new Complex();
		System.out.println("Real:"+real);
		System.out.println("Imag:"+imag);
	}
}
public class ConstructorPrivate
{
	public static void main(String[] args)
	{
		//Complex c1 = new Complex(10, 20);
		//c1.accept();
		Complex.accept();
	}
}