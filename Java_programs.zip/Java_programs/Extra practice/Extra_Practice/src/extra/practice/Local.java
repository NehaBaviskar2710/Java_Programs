package extra.practice;

public class Local
{
	public static void main(String[] args)
	{
		String name = "Neha";
		int id = 123;
		float salary = 50000.89f;
		
		System.out.println("Name :"+name);
		System.out.println("Id :"+id);
		System.out.println("Salary :"+salary);
		
	}
	public static void main1(String[] args)
	{
		int number = 10;
		System.out.println("Number is:" +number);
	}
}