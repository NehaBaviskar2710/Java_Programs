package extra.practice;

public class Printing
{
	public static void main(String[] args)
	{
		System.out.print("My name is Neha Baviskar");
		System.out.println("I am from Dhule");
		System.out.printf("I like to learn some new things");
		
	}
}