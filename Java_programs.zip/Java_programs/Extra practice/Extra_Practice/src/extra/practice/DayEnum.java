package extra.practice;

enum Day
{
	MON("Monday"), TUES("Tuesday"), WED("Wednesday");
	
	private String dayName;
	private Day(String dayName)
	{
		this.dayName = dayName;
	}
	public String getDayName()
	{
		return dayName;
	}
}
public class DayEnum 
{
	public static void main(String[] args)
	{
		Day day = Day.MON;
		System.out.println(day.name()+" "+day.ordinal());
		System.out.println(day.getDayName());
	}
}
