package extra.practice;

class Program
{
	int day;
	int month;
	int year;
	Program()
	{
		System.out.println("Parameterless constructor is called");
	}
}
class Parameterless
{
	public static void main(String[] args)
	{
		Program p = new Program();
	}
}