package extra.practice;

import java.util.Calendar;
class CalendarClass
{
	public static void main(String[] arsg)
	{
		Calendar cal = Calendar.getInstance();
		System.out.println("Date:");
		int day = cal.get(Calendar.DATE);
		System.out.println("Month");
		int month = cal.get(Calendar.MONTH)+1;
		System.out.println("Year:");
		int year = cal.get(Calendar.YEAR);
		System.out.println(day+"/ "+month+" / "+year);
		
	}
}