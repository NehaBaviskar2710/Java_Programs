package extra.practice;

class ClassFieldsCall
{
	private int num1; //non-static, insatnce variable
	private static int num2; //static , class level variable
	
	public void getNum1(int num1)
	{
		this.num1= num1;
		System.out.println("number 2 is:" +this.num1);
	}
	
	public static void getNum2(int num2)
	{
		num2 = num2;
		System.out.println("number 2 is:" +num2);
	}
	
	public static void main(String[] args)
	{
		ClassFieldsCall cf = new ClassFieldsCall();
		cf.getNum1(293);
		
		ClassFieldsCall.getNum2(393);
		
	}

}
