package extra.practice;

public class ArrayLength
{
	private static void printRecord(int[] arr)
	{
		for(int index = 0; index < arr.length; index++)
		{
			System.out.println(arr[index]);
		}
	}
	
	public static void main(String[] args)
	{
		int arr1[] = new int[] {10, 20, 30};
		ArrayLength.printRecord(arr1);
		
		int arr2[] = {10, 20, 30, 40, 50};
		ArrayLength.printRecord(arr2);
		
		int arr3[] = new int[] {10, 20, 30, 40};
		ArrayLength.printRecord(arr3);
	}
}