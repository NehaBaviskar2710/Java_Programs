package extra.practice;

class Fields
{
	static int count = 0;
	
	public static void accept()
	{
		count = count +1;
		System.out.println("Count:"+count);
	}
	
}
public class ClassFieldStatic
{
	public static void main(String[] args)
	{
		Fields.accept();
		Fields.accept();
		Fields.accept();
	}
}
