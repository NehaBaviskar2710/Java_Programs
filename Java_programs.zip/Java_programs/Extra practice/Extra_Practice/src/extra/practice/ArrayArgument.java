package extra.practice;

import java.util.Scanner;
public class ArrayArgument
{
	private static Scanner sc = new Scanner(System.in);
	public static void acceptRecord(int[] number)
	{
		System.out.println("Enter a number:");
		number[0] = sc.nextInt();
	}
	public static void printRecord(int[] number)
	{
		System.out.println("Number:"+number);
	}
	public static void main(String[] args)
	{
		int[] number = new int[1];
		ArrayArgument.acceptRecord(number);
		ArrayArgument.printRecord(number);
		
		
	}
}