package extra.practice;

class SameNameDiffParameter
{
	static void mul(int s1, float s2)
	{
		float total = s1*s2 ;
		System.out.println("Multiplication of 2 numbers:"+total);
	}
	static void mul(float f1, float f2)
	{
		float total1 = f1*f2;
			System.out.println("Total is:"+total1);
	}
	public static void main(String[] args)
	{
		SameNameDiffParameter.mul(10, 39.08);
		SameNameDiffParameter.mul(20.3, 38.20);
	}
}