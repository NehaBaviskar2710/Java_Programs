package extra.practice;

public class ArrayIndex
{
	public static void main(String[]args)
	{
		int arr[] = new 
	}
	public static void main1(String[] args)
	{
		int arr[] = new int[] {10, 20, 30,4};
		int element = arr[arr.length];
		System.out.println(element);
		
	}
}