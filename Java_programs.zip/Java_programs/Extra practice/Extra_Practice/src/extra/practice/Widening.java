package extra.practice;

class Widening
{
	public static void main(String[] args)
	{
		long id2 = 1000l;
		float id3 = (float)id2;
		System.out.println("Id3:"+id3);
		
	}
	public static void mai5(String[] args)
	{
		int money = 100;
		float cash = (float)money;
		System.out.println("Cash:"+cash);
		
	}
	public static void main4(String[] args)
	{
		int rollno = 123;
		long roll = (long)rollno;
		System.out.println("Roll no:"+rollno);
	}
	public static void main3(String[] args)
	{
		short id = 12;
		int id1 = (int)id;
		System.out.println("Id1:"+id1);
	}
	public static void main2(String[] args)
	{
		float salary = 10000f;
		double salary1 = (double)salary;
		System.out.println("Salary:"+salary1);
	}
	public static void main1(String[] args)
	{
		int num1 = 10;
		double num2 = (double)num1;
		System.out.println("Number 2:"+num2);
	}
}
