package extra.practice;

class Const
{
	int day;
	int month;
	int year;
	
	Const(int day, int month, int year)
	{
		System.out.println("Parameterised constructor");
		this.day = day;
		this.month = month;
		this.year = year;
		System.out.println(day+" / "+month+" / "+year);
	}
}
class Parameterised
{
	public static void main(String[] args)
	{
		Const c = new Const(18, 2, 2024);
	}
}