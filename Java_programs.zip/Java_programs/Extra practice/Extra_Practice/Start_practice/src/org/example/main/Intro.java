package org.example.main;

public class Intro 
{
	private int n1;
	private static int n2;
	
	public void setN1(int n1)
	{
		this.n1=n1;
	}
	public static void setN2(int n2)
	{
		this.n2 = n2;
	}
	public static void main(String[] args)
	{
		Intro.setN2(10);
		Intro i = new Intro();
		i.setN1(20);
	}
}
