package org.example.main;

import java.util.Date;
class Box
{
	private Object reference;
	public Object getReference()
	{
		return reference;
		//System.out.println(reference);
	}
	public void setReference(Object reference)
	{
		this.reference = reference;
	}
}
public class Program 
{
	public static void main(String[] args)
	{
		Box b1 = new Box();
		b1.setReference(new Date());
	}
	public static void main1(String[] args)
	{
		Box b1  = new Box();
		b1.setReference(123);
	}
}
