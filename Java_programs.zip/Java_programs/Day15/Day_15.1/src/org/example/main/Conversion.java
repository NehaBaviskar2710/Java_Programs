package org.example.main;

public class Conversion 
{
	public static void main3(String[] args)
	{
		Integer i = new Integer(123);
		int number = i.intValue();
		System.out.println(number);
	}
	public static void main2(String[] args)
	{
		int number = 123;
		Object obj = 123;
		System.out.println(obj);
	}
	public static void main1(String[] args)
	{
		int number = 123;
		//Integer i = Integer.valueOf(number);
		//Number n = Integer.valueOf(number);
		Object o = Integer.valueOf(number);
		System.out.println(o.toString());
		
	}
}
