package org.example.main;

public class UnBoxing 
{
	public static void main(String[] args)
	{
		Integer i = new Integer(123);
		int number = i.intValue();
		System.out.println(number);
	}
	
	public static void main2(String[] args)
	{
		int number = 123;
		Integer i = Integer.valueOf(number);
		int num = i.intValue();
		System.out.println(num);
	}
	public static void main1(String[] args)
	{
		String str = "123";
		int number = Integer.parseInt(str);
		System.out.println("Number:"+number);
	}
}
