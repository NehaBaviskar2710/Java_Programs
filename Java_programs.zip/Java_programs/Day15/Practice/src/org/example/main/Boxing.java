package org.example.main;

import java.lang.Object;
public class Boxing 
{
	public static void main(String[] args)
	{
		int number = 123;
		String str = Integer.toString(number);
		System.out.println(str); 
	}
	public static void main2(String[] args)
	{
		int number = 123;
		Integer i = Integer.valueOf(number);
		System.out.println(i);
	}
	public static void main1(String[] args)
	{
		int num = 10;
		Integer i = new Integer(num);
		System.out.println(i);
	}
}
