package org.example.main;

import java.util.Date;
class Casting<Date>
{
	private Date reference;
	public Date getReference()
	{
		return reference;
	}
	public Object setReference(Date reference)
	{
		this.reference = reference;
	}
}
public class Generics 
{
	public static void main(String[] args)
	{
		Casting<Date> c = new Casting<>();
		c.setReference(123);
		
	}
}
