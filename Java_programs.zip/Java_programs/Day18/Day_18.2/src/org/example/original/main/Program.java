package org.example.original.main;

import java.util.Scanner;

public class Program 
{
	public static void main(String[] args)
	{
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Enter F.Q. class name");
			String className = sc.nextLine();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
