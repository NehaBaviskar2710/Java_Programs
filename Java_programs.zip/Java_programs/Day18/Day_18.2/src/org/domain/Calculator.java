package org.domain;

public class Calculator 
{
	public int sum(int num1, float num2, double num3)
	{
		return num1+num2+num3;
	}
	public int sub(int num1, unt num2)
	{
		return num1-num2;
	}
}
