import java.time.LocalDate;
import java.util.Scanner;

class Date{
    int day;
    int month;
    int year;
    Date(int day, int month, int year){
        System.out.println("Inside constructor:");
        this.day = day;
        System.out.println("DAY:"+this.day);
        this.month = month;
        System.out.println("Month:" +this.month);
        this.year = year;
        System.out.println("Year:"+this.year);
    }
}
class Program{
    public static void main(String[] args){
        Date dt1 = new Date(7, 8, 2023);
    }
}