
class Date{
    int day;
    int month;
    int year;

    Date(){
        System.out.println("Parameterless constructor:");
        this.day=0;
        System.out.println("day:"+this.day);
        this.month=0;
        System.out.println("Month:"+this.month);
        this.year=0;
        System.out.println("Year:"+this.year);
    }
    Date(int day, int month, int year){ //CConstructor Overloading
        System.out.println("Parameterised constructor:");
        this.day = day;
        System.out.println("Day:"+this.day);
        this.month = month;
        System.out.println("Month:"+this.month);
        this.year = year;
        System.out.println("Year:"+this.year);

    }
}
class Program{
    public static void main(String[] args){
        Date dt = new Date();
        Date dt1 = new Date(18, 9, 2023);
    }
}