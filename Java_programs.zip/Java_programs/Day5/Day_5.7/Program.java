class Date{
    int day;
    int month;
    int year;

    Date()
    {
        this(10, 9, 2023);
    
    }

    Date(int day, int month, int year)
    {
        this.day=day;
        this.month=month;
        this.year=year;
    }


    void printRecord()
    {
        System.out.println(this.day+" / " +this.month+ " / " +this.year);
    }
}
class Program{
    public static void main(String[] args){
        Date dt = new Date();
        dt.printRecord();

        Date dt2 = new Date(18, 10, 2023);
        dt2.printRecord();
    }
}