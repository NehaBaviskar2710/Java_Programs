class Employee
{
   private String name;
   private int empid;
   private float salary; 
   public String getName()
    {
        return this.name;
    }
    public int getEmpId()
    {
        return this.empid;
    }
    public float getSalary()
    {
        return this.salary;
    }
}
class Program
{
    public static void main(String[] args)
    {
        Employee emp = new Employee();
        String name = emp.getName();
        int empid = emp.getEmpId();
        float salary = emp.getSalary();
        System.out.println(name +" " + empid +" " + salary);
    }
}