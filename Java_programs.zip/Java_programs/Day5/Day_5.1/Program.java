import java.util.Scanner;
class Date{
    int day;
    int month;
    int year;

    Date(){
        LocalDate ld = LocalDate.now();
        this.day = ld.getDayOfMonth();
        this.month = ld.getMonthValue();
        this.year = ld.getYear();
    }
    void acceptRecord(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Day"); //to accept field of class
        day = sc.nextInt(); //field of class
        System.out.println("month");
        month = sc.nextInt(); //field of class
        System.out.println("Year");
        year = sc.nextInt(); //field of class
    }
    void printRecord(){
        System.out.println(this.day+ " / " + this.month+ " /  " +this.year);
    }

}
class Program{
    public static void main(String[] args){
        Date dt = new Date(); //operations performed on same instance
        dt.initDate(17, 8, 2023);
        dt.acceptRecord();
        dt.printRecord();

    }
}