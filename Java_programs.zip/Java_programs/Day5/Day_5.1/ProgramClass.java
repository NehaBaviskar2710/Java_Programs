import java.util.Scanner;
import java.util.LocalDate;
class Date{
    int day;
    int month;
    int year;

    Date(){
        System.out.println("Inside Constructor");
        LocalDate ld = LocalDate.now();
        this.day = ld.getDayOfMonth();
        this.month = ld.getMonthValue();
        this.year = ld.getYear();
    }
    
    void printRecord(){
        System.out.println(this.day+ " / " + this.month+ " /  " +this.year);
    }

}
class ProgramClass{
    public static void main(String[] args){
        Date dt1;
        Date dt2;
    }
    public static void main2(String[] args)
    {
        Date dt1 = new Date();
    }
    public static void main1(String[] args)
    {
        Date dt2 = new Date();
    }
}