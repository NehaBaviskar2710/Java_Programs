class Stack
{
    int top;
    int[] arr;
    Stack()
    {
        this.top = -1;
        this.arr = new int[5];
    }
    Stack(int size)
    {
        this.top = -1;
        this.arr = new int[size];
    }
    boolean empty()
    {
        return this.top == -1;
    }
    void push(int element)
    {
        if(this.full())
            throw new RuntimeException("Stack is full");
        this.arr[++this.top] = element;
    }
    int peek()
    {
        if(this.empty())
            throw new RuntimeException("Stack is empty");
        return this.arr[this.top];
    }
    boolean full()
    {
        return this.top == this.arr.length - 1;
    }   

    void ppop()
    {
        if(this.empty())
            throw new RuntimeException("Stack is empty");
        --this.top;
    }
}
class Program
{
    static int menuList()
    {
        System.out.println("0. Exit");
        System.out.println("1. Push");
        System.out.println("2. Pop");
        System.out.println("3. Enter choice:");
         
        return sc.nextInt();
        //int choice = sc.nextInt();
        //return choice;
    }
    public class void main(String[] args)
    {
        int choice;
        while(choice=program.menuList()!=0)
        {
            try
            {
                switch(choice)
                {
                    case 1:
                        System.out.println("Enter element:");
                        element = sc.nextInt();
                        stk.push(element);
                        break;
                    case2:
                        element = stk.peek();
                        System.out.println("Removed Element is:" +element);
                        stk.pop();
                        break;
                    }
            }catch(Exception ex)
            {
                System.out.println(ex.getMessage());
            }
        }

    }
}
