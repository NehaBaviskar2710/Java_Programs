class Student
{
    //data hiding
    private String name;
    int rollno;
    float marks;
}
class Program
{
    public static void main(String[] args)
    {
        Student s = new Student();
        s.name = "neha";
        s.rollno = 65;
        s.marks = 98.78f;
    }
}
