class Student
{
    private String name;
    private int rollno;
    private float marks;
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return this.name;
    }
    public void setRollNumber(int rollno)
    {
        this.rollno = rollno;
    }

    public int getRollNumber()
    {
        return this.rollno;
    }

    public void setMarks(float marks)
    {
        this.marks = marks;
    }

    public float getMarks()
    {
        return this.marks;
    }
}
class Program1
{
    public static void main(String[] args)
    {
        Student s = new Student();
        s.setName("neha");
        s.setRollNumber(29);
        s.setMarks(89.38f);

        String name = s.getName();
        int rollno = s.getRollNumber();
        float marks = s.getMarks();
        System.out.println(name+" "+rollno+" "+marks);

    }
}