class Test
{
    int num1 = 10;
    void printRecord()
    {
        System.out.println("Value:" +num1);
    }
    //instance initialization block
    {
        this.num1=20;
    } 
    Test()
    {
        this.num1=30;
    }
}
class Program{
    public static void main(String[] args)
    {
        Test t = new Test();
        t.printRecord();
    }
}