class Employee
{
    private String name;
    private int empid;
    private float salary;

    public String getName()
    {
        return this.name;
    }
    public void setName(String name)
    {
        this.name = name;
    }
    public int getEmpId()
    {
        return this.empid;
    }
    public void setEmpId(int empid)
    {
        this.empid = empid;
    }
    public float getSalary()
    {
           return this.salary;
    }
    public void setSalary(float salary)
    {
        this.salary = salary;
    }
}
class EmployeeTest
{
    private Employee emp = new Employee();
    public void acceptRecord()
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Name:");
        emp.setName(sc.nextLine());
        System.out.println("Empid:");
        emp.setEmpId(sc.nextInt());
        Sytsem.out.println("Salary:");
        emp.setSalary(sc.nextFloat());
        String name = emp.getName();
        int empid = emp.getEmpId();
        float salary = emp.getSalary();
        
         
    }
    public void printRecord()
    {
        System.out.println(emp.getName()+ " " +emp.getEmpId()+ " " +emp.getSalary());
    }
}
class Program
{
    public static void main(String[] args)
    {
        Employee emp = new Employee();
        
    }
}