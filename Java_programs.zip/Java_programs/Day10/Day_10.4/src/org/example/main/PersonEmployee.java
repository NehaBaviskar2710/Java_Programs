package org.example.main;

class Person1
{
	String name;
	int id;
	
	public Person1()
	{
		System.out.println("Public Person(");
		this.name = " ";
		this.id = 0;
	}
	public Person1(String name, int id)
	{
		System.out.println("Parameterised");
		this.name = name;
		this.id = id;
	}
	
	public void showRecord()
	{
		System.out.println("Name:"+this.name);
		System.out.println("Id:"+this.id);
	}
}

class Employee extends Person1
{
	int age;
	float salary;
	
	public Employee()
	{
		System.out.println("Parameterless Constructor");
		this.age = 0;
		this.salary = 0.0f;
	}
	public Employee(String name, int id, int age, float salary)
	{
		super(name, id);
		System.out.println("Employee constructor");
		this.age = age;
		this.salary = salary;
	}
	
	public void display()
	{
		this.showRecord();
		System.out.println("Age:"+this.age);
		System.out.println("Salary:"+this.salary);
	}
	
}
public class PersonEmployee
{
	public static void main(String[] args)
	{
		//Person1 p = new Person1();
		//Person1 p = new Person1("Paresh", 12);
		//Employee emp = new Employee();
		Employee emp = new Employee("KIMAY", 56, 26, 1000000.08f);
	}
	public static void main5(String[] args)
	{
		Employee emp = new Employee();
		emp.name = "Jay";
		emp.id = 123;
		emp.age = 17;
		emp.salary = 100000000.10f;
		//emp.showRecord();
		emp.display();
	}
	public static void main1(String[] args)
	{
		Person1 p = new Person1();
		p.name = "neha";
		p.id = 23;
	}
}
