package org.example.main;

class Worker
{
	String name;
	int age;
	float salary;
	
	public Worker()
	{
		this(" ", 0, 0.0f);
	}
	
	public Worker(String name, int age, float salary)
	{
		this.name = name;
		this.age = age;
		this.salary = salary;
	}
	
	public void showRecord()
	{
		System.out.println(this.name+" "+this.age+" "+this.salary);
	}
}
public class EmployeePro
{
	public static void main(String[] args)
	{
		Worker emp = new Worker();
		//Worker emp = new Worker("Neha", 20, 1000000.29f);
		emp.showRecord();
	}
}
