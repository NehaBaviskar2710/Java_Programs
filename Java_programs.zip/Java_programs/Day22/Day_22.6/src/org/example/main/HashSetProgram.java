package org.example.main;

import java.util.HashSet;
import java.util.Set;

public class HashSetProgram 
{
	public static void main(String[] args)
	{
		Set<Integer> set = new HashSet();
		set.add(30);
		set.add(50);
		set.add(992);
		set.add(20);
		set.add(58);
		set.add(null);
	
		set.add(30);
		set.add(50);
		set.add(992);
		set.add(20);
		set.add(58);
		System.out.println(set);
	}
	
	public static void main2(String[] args)
	{
		Set<Integer> set = new HashSet();
		set.add(30);
		set.add(50);
		set.add(992);
		set.add(20);
		set.add(58);
		System.out.println(set);
	}
	
	public static void main1(String[] args)
	{
		//HashSet<Integer> set = new HashSet();
		Set<Integer> set = new HashSet();
	}
}
