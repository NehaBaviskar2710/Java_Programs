package org.example.test;

import java.util.Scanner;
import java.util.TreeSet;
import org.example.domain.Book;
import java.util.Comparator;
import org.example.domain.Book;
import java.util.Set;

public class SetTest 
{
	private Set<Book> bookList;
	
	public void setBookList(Set<Book> bookList)
	{
		this.bookList = bookList;
	}
	
	public void addBook(Book book)
	{
		if(this.bookList != null)
		{
			this.bookList.add(book);
		}
	}
	
	public void addBooks(Book[] arr)
	{
		if(this.bookList != null)
		{
			if(arr != null)
			{
				for(Book book:arr)
				{
					this.bookList.add(book);
				}
//			this.bookList.add(arr[0]);
//			this.bookList.add(arr[0]);
//			this.bookList.add(arr[0]);
			}
		}
	}
	public Book findBook(int id)
	{
//		for(Book book :this.bookList)
//		{
//			if(book.getId()== bookId)
//			{
//				return book;
//			}
//		}
		if(this.bookList != null)
		{
			for(Book book: bookList)
			{
				if(book.getId() == id)
					return book;
			}
		}
		return null;
	}
	public boolean removeBook(int bookId)
	{
		Book key = new Book();
		key.setId(bookId);
		if(this.bookList.contains(key))
		{
			this.bookList.remove(key);
			return true;
		}
		return false;
	}
	public void printBooks()
	{
		this.bookList.forEach(System.out::println);
	}
	
	
	//To do
	
	//
	//
	
}
