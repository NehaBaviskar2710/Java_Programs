package org.example.main;

import java.util.TreeSet;
import java.util.Set;
import java.util.Collection;

public class SetProgram 
{
	public static void main(String[] args)
	{
		Set<Integer> set = new TreeSet<>();
		set.add(10);
		set.add(20);
		set.add(30);
		set.add(40);
		set.add(50);
		//set.add(null);
		
		System.out.println(set);
	}
	public static void main2(String[] args)
	{
		Set<Integer> set = new TreeSet<>();
		set.add(10);
		set.add(20);
		set.add(30);
		set.add(40);
		set.add(50);
		
		set.add(10);
		set.add(20);
		set.add(30);
		set.add(40);
		set.add(50);
		
		System.out.println(set);
//		Integer element = null;
//		while(!set.isEmpty());
//		{
//			
//		}
	}
	public static void main1(String[] args)
	{
		TreeSet<Integer> treeset = new TreeSet<>();
		
		Set<Integer> set = new TreeSet<>();
		
		Collection<Integer> collection = new TreeSet<>();
		
	}
}
