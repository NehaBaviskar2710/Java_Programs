package org.example.main;

public class DictionaryProgram 
{
	public static void main(String[] args)
	{
		
	}
}
