package org.example.main;

public class Program 
{
	public static void main1(String[] args)
	{
		String str1 = "Neha";
		String str2 = "Neha";
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
	}
}
