package org.main.domain;


public class VariableArgument
{
	private static void sum(int... arguments)
	{
		int result = 0;
		for(int element : arguments )
		{
			result = result + element;
		}
		System.out.println("Result:"+result);
	}
	public static void main(String[] args)
	{
		VariableArgument.sum(10, 20);
		VariableArgument.sum(39, 40,2 , 20);
		VariableArgument.sum(30, 50, 29);
		VariableArgument.sum(10,40, 26, 78,59, 70, 49, 29);
	}
}
