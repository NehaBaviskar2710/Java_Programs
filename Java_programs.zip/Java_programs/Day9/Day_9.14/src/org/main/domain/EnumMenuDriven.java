package org.main.domain;

public class EnumMenuDriven 
{
	
}
