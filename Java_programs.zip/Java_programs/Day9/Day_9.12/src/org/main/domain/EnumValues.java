package org.main.domain;

enum Day
{
	MON(1, "Monday"), TUES(2, "Tuesday"), WED(3, "Wednesday");
	
	private String dayName;
	int dayNumber;
	private Day(String dayName, int dayNumber)
	{
		this.dayName  = dayName;
		this.dayNumber = dayNumber;
	}
	
	public int getName()
	{
		System.out.println(this.dayName);
	}
	
	public String getNumber()
	{
		System.out.println(dayNumber);
	}
}

class EnumValues
{
	public static void main(String[] args)
	{
		Day days = Day.MON;
		System.out.println(days.name());
		System.out.println(days.ordinal());
		
		days.getName();
		days.getNumber();
	}
}