package org.main.domain;

public class Employee 
{
	public static void main(String[] args)
	{
		Employee[][] arr = new Employe[2][2];
	}
}
