package org.main.domain;

enum Color
{
	RED, GREEN, BLUE;
}
public class EnumNonPrimitive 
{
	public static void main(String[] args)
	{
		Color[] colors = Color.values();
		for(Color color : colors)
			System.out.println(color.name()+" "+color.ordinal());
	}
	public static void main4(String[] args)
	{
		Color color = Color.RED;
		System.out.println(color.name()+" "+color.ordinal());
		
		color = Color.GREEN;
		System.out.println(color.name()+" "+color.ordinal());
		
		color = Color.BLUE;
		System.out.println(color.name()+" "+color.ordinal());
	}
	public static void main3(String[] args)
	{
		System.out.println(Color.BLUE.name());
		System.out.println(Color.BLUE.ordinal());
	}
	public static void main2(String[] args)
	{
		System.out.println(Color.GREEN.name());
		System.out.println(Color.GREEN.ordinal());
	}
	public static void main1(String[] args)
	{
		System.out.println(Color.RED.name());
		System.out.println(Color.RED.ordinal());
	}
}
