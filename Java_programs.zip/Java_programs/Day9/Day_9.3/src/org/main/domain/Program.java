package org.main.domain;

import java.util.Arrays;
public class Program
{
	private static void getArray()
	{
		int[][] arr = new int[4][];
		int[0] arr = new int[4];
		
		
	}
	
	public static void main(String[] args)
	{
		int[][] arr = Program.getArray();
	}
}
