package org.main.domain;

import java.util.Arrays;
public class RaggedArray
{
	public static void main(String[] args)
	{
		int[][] arr = new int[4][4];
		arr[0] = new int[] {1,8,6};
		arr[1] = new int[] {5,8,4};
		arr[2] = new int[] {4,7,3};
		arr[3] = new int[] {9,3,7};
		System.out.println(Arrays.deepToString(arr));
		
		System.out.println(Arrays.toString(arr));
		
		System.out.println(Arrays.toString(arr[0]));
		System.out.println(Arrays.toString(arr[1]));
		System.out.println(Arrays.toString(arr[2]));
		System.out.println(Arrays.toString(arr[0]));
		System.out.println(Arrays.toString(arr[3]));
		
		for(int index = 0; index<4; index++)
			System.out.println(Arrays.toString(arr[index]));
		
		for(int[] row: arr)
			for(int col: row )
				System.out.println(col+"");
			System.out.println();
	}
	public static void main2(String[] args) {
		int[ ][ ] arr = new int[ 4 ][ ];
		arr[ 0 ] = new int[ 3 ];
		arr[ 1 ] = new int[ 5 ];
		arr[ 2 ] = new int[ 2 ];
		arr[ 3 ] = new int[ 4 ];
		}

	public static void main1(String[] args)
	{
		//ragged array reference declaration
		int[][] arr1 = null;
		int[] arr2[] = null;
		int arr3[][] = null;
		
	}
}