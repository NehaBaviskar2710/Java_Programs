package org.main.domain;

enum Day
{
	MON("Monday");
	
	private String dayName;
	private Day(String dayName)
	{
		this.dayName = dayName;
	}
	
	public void getDayName()
	{
		System.out.println(dayName);
	}
}
public class EnumLiterals {
	
	public static void main(String[] args)
	{
		Day day = Day.MON;
		System.out.println(day.name()+" "+day.ordinal());
		day.getDayName();
	}
}
