package org.main.domain;


enum Day
{
	MON(0), TUES(2), WED(3);
	
	int daynumber;
	private Day(int daynumber)
	{
		this.daynumber = daynumber;
	}
	public void getNumber()
	{
		System.out.println(daynumber);
	}
}
public class EnumLiterals 
{
	public static void main(String[] args)
	{
		Day day = Day.MON;
		System.out.println(day.name());
		System.out.println(day.ordinal());
		day.getNumber();
	}
}
