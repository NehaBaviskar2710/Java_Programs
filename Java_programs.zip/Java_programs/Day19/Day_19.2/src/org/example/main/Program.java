package org.example.main;

import java.lang.Thread.State;

class Sample
{
	public Sample()
	{
		System.out.println("Inside constructor of"+this.getClass().getSimpleName());
	}
	public void print( ) 
	{
		System.out.println("Inside print method of"+this.getClass().getSimpleName());
	}
	@Override
	protected void finalize() throws Throwable 
	{
		System.out.println("Inside finalize method of"+this.getClass().getSimpleName());
	}
}
public class Program 
{
	public static void main1(String[] args)
	{
		Thread thread = Thread.currentThread();
		String name = thread.getName();
		System.out.println("Thread Name:"+name);
		
		int p = thread.getPriority();
		System.out.println("Thread priority:"+p);
		
		ThreadGroup group = thread.getThreadGroup();
		System.out.println("Thread Group: "+group.getName());
		
		State state = thread.getState();
		System.out.println("Thread State : "+state.name());
		
		boolean type = thread.isDaemon();
		System.out.println("Thread Type : "+( type ? "Daemon Thread"
		: "User Thread") );
		
		boolean status = thread.isAlive();
		System.out.println("Thread Status : "+( status ? "Alive" :
		"Dead") );
		
	}
	public static void main(String[] args)
	{
		Sample sample = null;
		sample = new Sample();
		sample.print();
		sample = null;
		System.gc();
		
	}
}
