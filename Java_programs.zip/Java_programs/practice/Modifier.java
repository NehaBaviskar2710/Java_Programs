class Student
{
    String name;
    int id;
    float marks;   
//     private String name;
//     private int id;
//     float marks;   
}

class Modifier 
{   
    public static void main(String[] args)
    {
        Student s = new Student();
        System.out.println("Student iformation:");
        s.name = "Neha";
        System.out.println(s.name);
        s.id = 123;
        System.out.println(s.id);
        s.marks = 2893.29f;
        System.out.println(s.marks);
    }
}
    


