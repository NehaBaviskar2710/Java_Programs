class Over 
{
    public static void main(String[] args)
    {
        System.out.println("Java");
        Over.main(123);
    }    
    public static void main(int arg)
    {
        System.out.println("Program");
    }
}
