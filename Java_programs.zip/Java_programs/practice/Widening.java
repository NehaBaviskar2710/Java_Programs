class Widening 
{
    public static void main(String[] args)
    {
        int number=123;
        double num1 = (double)number;
        System.out.println("Number is:" +num1);

        long num2 = (long)number;
        System.out.println("Number is:" +num2);
    }    
}
