class Format 
{
    public static void main(String[] args)
    {
        String name1 = "Neha";
        int empid= 10281;
        float salary = 120000.90f;

        System.out.println(name1+" "+" ");
    }    
}
