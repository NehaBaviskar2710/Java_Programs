class Space 
{
    public static void main(String[] args)
    {
        System.out.println("Sum is:" +(10+20));
    }    
}
