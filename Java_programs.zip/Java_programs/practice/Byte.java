class Byte
{
    public static void main(String[] args)
    {
        byte value = 124;
        Byte bs = new
    }
    public static void main(String[] args)
    {
        byte value = 129;
        Byte bs = Byte.valueOf(value);
    }
    public static void main1(String[] args)
    {
        byte value = 123;
        System.out.println(value);
    }
}