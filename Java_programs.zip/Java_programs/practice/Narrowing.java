class Narrowing {
    
}
