class Try
{
    private int number;
   
    public void showRecord()
    {
        this.number = this.number+1;
        System.out.println("Number is:" +this.number);
    }
}
class ThisRef 
{
    public static void main(String[] args)
    {
        Try t = new Try();
        t.showRecord();
    }    
}
