class Date
{
    int day;
    int month;
    int year;
    Date(int day, int year, int month)
    {
        this.day = day;
        this.month = month;
        this.year= year;
    }
}
class ParConst 
{
    public static void main(String[] args)
    {
        //Date d = new Date();
        Date d1 = new Date(11, 2, 2024);
    }    
}
