class Mul 
{
    public static void main(String[] args)
    {
        System.out.println("Java");
    }    
}
class Sum
{
    public static void main(String[] args)
    {
        System.out.println("Program");
    }   
}
