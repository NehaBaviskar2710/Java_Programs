class FinalModifier 
{
    public static void main(String[] args)
    {
        final int number=10;
        //number = 20;
        System.out.println("Number is:" +number);
    }
}
