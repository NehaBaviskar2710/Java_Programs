class Date
{
    int day;
    int month;
    int year;
    Date(int day, int month, int year)
    {
        System.out.println("Initalize constructor");
        this.day = day;
        this.month = month;
        this.year = year;
        System.out.println( this.day+ " / " +this.month+ " / " +this.year);
    }
}
class Const 
{
    public static void main(String[] args)
    {
        Date d = new Date(11, 2, 2024);
    }
}

