class Date
{
    int day;
    int month;
    int year;

    Date()
    {
        this.day= 0;
        this.month = 0;
        this.year = 0;
    }
    Date(int day, int month, int year)
    {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    void printRecord()
    {
        System.out.println(this.day+ " / " +this.month+ " / " +this.year);
    }
}
class ConstBoth 
{
    public static void main(String[] args)
    {
        Date d1 = new Date();
        d1.printRecord();
        Date d2 = new Date(11, 2, 2024);
        d2.printRecord();
    }    
}
