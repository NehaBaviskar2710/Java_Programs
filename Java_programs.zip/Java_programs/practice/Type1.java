class Type1 
{
    public static void main(String[] args)
    {
        int number = 20;
        System.out.println(number);
    }    
}
