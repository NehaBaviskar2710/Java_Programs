public class TryPrint 
{
    public static void main(String[] args)
    {
        System.out.print("Hello");
        System.out.print("Java");
        System.out.print("Prograaming");
    }    
}
