import java.util.Scanner;
class User 
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Name:");
        sc.nextLine();
        System.out.print("Id:");
        sc.nextInt();
        System.out.print("Salary:");
        sc.nextFloat();
    }    
}
