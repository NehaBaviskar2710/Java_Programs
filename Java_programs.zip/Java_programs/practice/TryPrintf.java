public class TryPrintf 
{
    public static void main(String[] args)
    {
        String name1 = "Neha";
        int id = 20;
        float salary = 20000.00f;

        String name1 = "Prachi";
        int id1 = 30;
        float salary2 = 30000.98f;

        System.out.printf(+name);
    }    
}
