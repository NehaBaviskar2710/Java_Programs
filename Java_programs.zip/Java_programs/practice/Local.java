public class Local
{
    public static void main(String[] args)
    {
        int num = 10;
        System.out.println("Nummber is:"+num);
    }    
}
