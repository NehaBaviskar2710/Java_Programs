class Boxing 
{
    public static void main(String[] args)
    {
        int number = 237;
        String str = Integer.toString(number);
        System.out.println("Number:" +number);
    }    
}
