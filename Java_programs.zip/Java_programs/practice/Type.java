/class Type
{
    public static void main(String[] args)
    {
        int number1;
        number1 = 20;
        System.out.println(number1);
    }
}