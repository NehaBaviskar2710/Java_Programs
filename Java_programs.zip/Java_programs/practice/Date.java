import java.util.Date;
class Date 
{
    public static void main(String[] args)
    {
        Date dt = new Date();
        int day = dt.getDate();
        int month = dt.getMonth();
        int year = dt.getYear();
        System.out.println(+day+ " / " +month+ " / " +year); 
    }    
}
