public class TryPrintln 
{
    public static void main(String[] args)
    {
        System.out.println("Hello");
        System.out.println("Java");
        System.out.println("Programming");
    }    
}
