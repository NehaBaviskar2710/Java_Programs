import java.util.Scanner;
class Employee 
{
    private String name;
    private int id;
    private float salary;   
    
    public Employee()
    {

    }

    public String getName()
    {
        return this.name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getId()
    {
        return this.id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public float getSalary()
    {
        return this.salary;
    }

    public void setSalary(float salary)
    {
        this.salary = salary;
    }
}
class setGet
{
    public static void main(String[] args)
    {
        Employee emp = new Employee();
        Scanner sc = new Scanner(System.in);

        

        emp.setName("Neha");
        emp.setId(393);
        emp.setSalary(200000.30f);

        String name = emp.getName();
        int id = emp.getId();
        float salary = emp.getSalary();

        System.out.println(name+ " " +id+ " " +salary);

    }
}
