import java.util.Date;
class CalDate 
{
    public static void main(String[] args)
    {
        Date dt = new Date();
        int day = dt.getDay();
        int month = dt.getMonth() +1;
        int year = dt.getYear() + 1900;

        System.out.println(+day+ " / " +month+ " / " +year);
    }    
}
