class Variable 
{
    //Fields
    private int num; //non static, instance variable
    private static int num1; //static, class variable
    
    //non static, instance method
    public void setNum(int num)
    {
        this.num=num;
    }

    //static , class level method
    public static void setNum1(int num1)
    {
        this.num1 = num1;

    }

    public static void main(String[] args)
    {
        Variable v = new Variable();
        v.setNum(122);

        Variable.setNum1(123);
    }
}
