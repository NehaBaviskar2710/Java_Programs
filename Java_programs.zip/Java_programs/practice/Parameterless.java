class Date
{
    int day;
    int month;
    int year;
    Date()
    {
        System.out.println("Initiallized constructor");
        this.day = day;
        this.month = month;
        this.year = year;
    }
}
class Parameterless 
{
    public static void main(String[] args)
    {
        Date d = new Date();
    }    
}
