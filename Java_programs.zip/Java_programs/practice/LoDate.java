import java.time.LocalDate;
class LoDate 
{
    public static void main(String[] args)
    {
        LocalDate ld = LocalDate.now();
        int day = ld.getDayOfMonth();
        int month = ld.getMonthValue();
        int year = ld.getYear();
        System.out.println(day+ " / " +month+ " / " +year);
    }
}
