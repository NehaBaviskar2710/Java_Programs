class Command 
{
    public static void main(String[] args)
     {
        System.out.println("Hello" +args[0]);
        System.out.println("Java" +args[1]);
        
        int number = Integer.parseInt(args[2]);
        System.out.println(+number);
     }   
}
