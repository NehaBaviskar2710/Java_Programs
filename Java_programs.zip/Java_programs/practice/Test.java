public class Test 
{
    private int num1;
    private static int num2;

    public void setNum1(int num1)
    {
        this.num1 = num1;
        System.out.println("Number1:" +this.num1);
    }

    public static void setNum2(int num2)
    {
        this.num2 = num2;
        System.out.println("Number 2:" +this.num2);
    }
    public static void main(String[] args) 
    {
        Test t = new Test();
        t.setNum1(10);

        Test.setNum2(20);
    }    
}
