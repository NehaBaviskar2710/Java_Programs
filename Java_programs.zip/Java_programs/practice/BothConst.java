class Date
{
    int day;
    int month;
    int year;

    Date()
    {
        System.out.println("Parameterless Constructor");
    }
    Date(int day, int month, int year)
    {
        System.out.println("Parameterized constructor");
        this.day= day;
        this.month = month;
        this.year = year;
        System.out.println(this.day+ " / " +this.month+ " / " +this.year);
    }
}
class BothConst 
{
    public static void main(String[] args)
    {
        Date d = new Date();
        Date d1 = new Date(11, 2, 2024);
    }    
}
