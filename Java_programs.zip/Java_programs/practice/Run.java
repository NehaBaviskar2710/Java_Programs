import java.lang.Scanner;
class Employee
{
    String name;
    int id;
    float salary;
    public void acceptRecord()
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Nmae:");
        this.name = sc.nextLine();
        System.out.println("Id:");
        this.id = sc.nextInt();
        System.out.println("Salary:");
        this.salary = sc.nextFloat();
    }   
    public void printRecord()
    {
        System.out.println(name+ " " +id+ " " +salary);
    } 
}

class Run 
{
    public static void main(String[] args)
    {
        Run r = null;
        r.acceptRecord();
        r.printRecord();
    }    
}
