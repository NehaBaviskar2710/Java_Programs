class Program
{
    int day;
    int month;
    int year;
}
class Default 
{
    public static void main(String[] args)
    {
        Program d = new Program();
    }
}
