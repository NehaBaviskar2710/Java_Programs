class Stat 
{
    //fields
    int num1;
    static int num2;
    public static void get()   
    {
        System.out.println("Num1");
    }
    public void set()
    {
        System.out.println("Num2");
    }

    public static void main(String[] args)
    {
        Stat.get();
        Stat s = new Stat();
        s.set();
    }
}
