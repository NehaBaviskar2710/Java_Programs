class Unboxing 
{
    public static void main(String[] args)
    {
        String str = new String("123");
        int number = Integer.parseInt(str);
        System.out.println("Number is " +number);
    }    
}
