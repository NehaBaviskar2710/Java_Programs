class LocalM 
{
    public static void main(String[] args)
    {
        int id=1;
        System.out.println("ID:" +id);
    }

}
