class Day 
{
    int day;
    int month;
    int year;
   
    void initDate(int day, int month, int year)
    {
        this.day = day;
        this.month = month; 
        this.year = year;
    }
    void printRecord()
    {
        System.out.println(this.day+ " / " +this.month+ " / " +this.year);
    }
}
class Prac
{
    public static void main(String[] args)
    {
        Day d = new Day();
        d.initDate(10,2,2024);
        d.printRecord();
    }    
}
