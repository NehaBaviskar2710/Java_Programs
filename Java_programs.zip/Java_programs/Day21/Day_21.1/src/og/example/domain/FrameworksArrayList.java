package og.example.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Collection;

public class FrameworksArrayList 
{
	public static List<Integer> getList()
	{
		List<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		return list;
		
	}
	public static void main(String[] args)
	{
		List<Integer> list = FrameworksArrayList.getList();
		for(int element : list)
			System.out.println(element);
	}
	public static void main7(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		int arr[] = new int[] {10, 20, 30, 40};
		int element = arr[arr.length];
	}
	public static void main6(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		Integer element = null;
		for(int index = 0; index<list.size(); index++)
		{	
			element = list.get(index);
			System.out.println(element);
		}
	}
	public static void main5(String[] args)
	{
		List<Integer> list = FrameworksArrayList.getList();
		System.out.println(list.toString());
	}
	public static void main4(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(40);
		list.add(50);
		list.add(2,30);
		System.out.println(list.toString());
	}
	public static void main3(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		System.out.println(list.toString());
	}
	public static void main2(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		if(list.isEmpty())
			System.out.println("Collection is Empty");
	}
	public static void main1(String[] args)
	{
		Collection<Integer> collection = new ArrayList<>();
		List<Integer> list = new ArrayList<>();
		ArrayList<Integer> arraylist = new ArrayList<>();
	}
}
