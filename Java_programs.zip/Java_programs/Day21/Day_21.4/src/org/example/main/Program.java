package org.example.main;

import org.example.domain.Book;

import org.example.test.ListTest;

import java.util.Comparator;

import java.util.Scanner;


import org.example.utils.IdComparator;
import org.example.utils.NameComparator;
import org.example.utils.AuthorComparator;
import org.example.utils.PriceComparator;
import org.example.utils.PublisherComparator;

public class Program 
{
	private static Scanner sc = new Scanner(System.in);
	
	private static Book[] getArray()
	{
		Book[] arr = new Book[10];
		arr[0] = new Book(1012, "The lord", "Rajesh Shastri", "Amitabh", 102.40f);
		arr[1] = new Book(1032, "Harry Potter", "Ram sharma", "Sanjay kapoor", 304.24f);
		return arr;
	}
	private static void acceptRecord(int[] bookId)
	{
		if(bookId != null)
		{
			System.out.println("Enter book id: ");
			bookId[0] = sc.nextInt();
		}
	}
	private static void printRecord(Book book)
	{
		if(book != null)
			System.out.println(book.toString());
		else
			System.out.println("Book not found");
	}
	private static void printRecord(boolean removedStatus)
	{
		if(removedStatus)
			System.out.println("Book is removed");
		else
			System.out.println("Book not found");
	}
	public static int menuList()
	{
		System.out.println("0.Exit");
		System.out.println("1.Add Books");
		System.out.println("2. Find Book");
		System.out.println("3. Remove Book");
		System.out.println("4. print Book ");
		System.out.println("Enter choice");
		return sc.nextInt();

		
	}
	public static int subMenuList()
	{
		System.out.println("0.Exit");
		System.out.println("1. Compare by bookid:");
		System.out.println("2. compare by bookname");
		System.out.println("3. compare by author");
		System.out.println("4. compare by publisher ");
		System.out.println("5.Compare by price");
		System.out.println("Enter choice");
		return sc.nextInt();

		
	}
	public static void main(String[] args)
	{		
		int choice;
		int[] bookId = new int[1];
		ListTest test = new ListTest();
		while((choice = Program.menuList())!=0)
		{
			switch(choice) {
			case 1:
				Book[] arr = Program.getArray();
				test.addBooks(arr);
				break;
			case 2:
				Program.acceptRecord(bookId);
				Book book = test.findBook(bookId[0]);
				Program.printRecord(book);
				break;
			case 3:
				Program.acceptRecord(bookId);
				boolean removedStatus= test.removeBook(bookId[0]);
				Program.printRecord(removedStatus );
				break;
			case 4:
				while((choice = Program.subMenuList())!=0)
				{
					Comparator<Book> comparator = null;
					switch(choice)
					{
					case 1:
						comparator = new IdComparator();
						break;
					case 2:
						comparator = new NameComparator();
						break;
					case 3:
						comparator = new AuthorComparator();
						break;
					case 4:
						comparator = new PublisherComparator();
						break;
					case 5:
						comparator = new PriceComparator();
						break;
					}
					test.printBooks(comparator);
				}
				
				break;
			
			}
		}
		
	}
	
}
