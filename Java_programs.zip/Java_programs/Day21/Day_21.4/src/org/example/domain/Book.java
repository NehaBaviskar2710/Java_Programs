package org.example.domain;

import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter @Setter
public class Book implements Comparable<Book>
{
	private  @EqualsAndHashCode.Include int id;
	private @EqualsAndHashCode.Exclude String name;
	private @EqualsAndHashCode.Exclude String author;
	private @EqualsAndHashCode.Exclude String publisher;
	private float price;
	
	@Override
	public boolean equals(Object obj)
	{
		if(obj!= null)
		{
			Book other = (Book) obj;
			if(this.id == other.id)
				return true;
		}
		return false;
	}
	@Override
	public int compareTo(Book other)
	{
		return this.id-other.id;
	}
	@Override
	public String toString()
	{
		return String.format("%-5d%-50s%-15s%-15s%-8.2f", this.id, this.name, this.author, this.publisher, this.price);
	}
}
