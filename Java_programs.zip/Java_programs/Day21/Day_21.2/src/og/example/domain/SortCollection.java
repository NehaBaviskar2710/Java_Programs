package og.example.domain;

import java.util.List;
import java.util.ArrayList;

public class SortCollection 
{
	public static void main(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		list.add(30);
		list.add(39);
		list.add(60);
		list.add(20);
		list.add(70);
		System.out.println("Before Sorting");
		System.out.println(list);
		list.sort(null);
		System.out.println("After sorting:");
		System.out.println(list);
		
	}
}
