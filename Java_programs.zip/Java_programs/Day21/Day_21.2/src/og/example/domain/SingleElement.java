package og.example.domain;

import java.util.ArrayList;
import java.util.List;

public class SingleElement 
{
	public static List<Integer> getList()
	{
		List<Integer> list = new ArrayList<>();
		for(int count = 1; count<=10; count++)
		{
			list.add(count*10);
		}
		return list;
			
	}
	public static void main(String[] args)
	{
		List<Integer> list = SingleElement.getList();
		//System.out.println(list);
		Integer key = new Integer(50);
		if(list.contains(key))
		{
			int index = list.indexOf(key);
			list.remove(index);
			System.out.println(list);
		}
		else
		{
			System.out.println(key+"not found");
		}
		
	}
}
