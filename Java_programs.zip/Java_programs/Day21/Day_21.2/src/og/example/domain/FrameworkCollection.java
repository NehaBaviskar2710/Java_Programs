package og.example.domain;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class FrameworkCollection 
{
	public static List<Integer> getList( )
	{
		List<Integer> list = new ArrayList<>();
		for( int count = 1; count <= 10; ++ count )
		{
			list.add( count * 10 );
		}
		return list;
	}
	public static void main(String[] args)
	{
		List<Integer> list = new ArrayList<>();
		Collection<Integer> keys = new ArrayList<>();
		keys.add(10);
		keys.add(20);
		
		keys.add(60);
		
	}
	public static void main1(String[] args)
	{
		Collection<Integer> collection = new ArrayList<>();
		collection.add(10);
		collection.add(20);
		collection.add(30);
		
		List<Integer> list = new ArrayList<>();
		list.addAll(collection);
		System.out.println(list);
		
	}
}
