import java.util.Calendar;
class Calendar{
    public static void main(String[] args){
        Calendar cr = new Calendar();
        int hour = Calendar.getHour();
        int minute = Calendar.getMinute();
        int second = Calendar.getSecond();
        System.out.println(hour+" / " +minute+ " / " +second);
    }
}