class Program{
    public static void main(String[] args){
        String str = "N";
        char ch = str.charAt(index:0);
        int codePoint = (int)ch;
        System.out.println(ch+" " +codePoint);
    }
    public static void main1(String[] args){
        char ch = 'N';
        int codePoint = (int)ch;
        System.out.println("Codepoint:" +codePoint);
    }
}