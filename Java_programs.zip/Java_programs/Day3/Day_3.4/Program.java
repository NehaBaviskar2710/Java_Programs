//Tke input from user by using Scanner classs
import java.util.Scanner;
class Program{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        int empid = sc.nextInt();
        float salary = sc.nextFloat();
        System.out.println("Name:" +name);
        System.out.println("Empid:" +empid);
        System.out.print("Salary:" +salary);
        System.out.print(name+" " +empid+ " " +salary);

    }
}