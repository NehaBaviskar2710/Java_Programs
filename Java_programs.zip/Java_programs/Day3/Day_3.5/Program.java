import java.util.Date;
class Program{
    public static void main(String[] args){
        Date date = new Date();
        int day = date.getDay();
        int month = date.getMonth();
        int year = date.getYear()+;
        System.out.println(day+" / " +month+" / " +year);
    }
}