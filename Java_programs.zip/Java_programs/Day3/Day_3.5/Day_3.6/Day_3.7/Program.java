import java.util.Calendar;
class Program{
    public static void main(String[] args){
        Calendar c = Calendar.getInstance();
        int day = c.get(Calender.DAY_OF+MONTH);
        int month = c.get(Calendar.MONTH);
        int year = c.get(Calendar.YEAR);
        System.out.println(day+ " / "; +month+ " / " +year );
    }
}