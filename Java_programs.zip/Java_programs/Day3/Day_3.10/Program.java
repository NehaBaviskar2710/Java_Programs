class Date{
    int day;
    int month;
    int year;
}
class Program{
    public static void main(String[] args){
        Date dt = new Date();
        dt1. a
    }
}