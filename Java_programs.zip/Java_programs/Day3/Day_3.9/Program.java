import java.time.LocalTime;
class Program{
    public static void main(String[] args){
        LocalTime lt = LocalTime.now();
        int hour = lt.getHour();
        int minute = lt.getMinute();
        int second = lt.getSecond(); 
        System.out.println(hour+ " / " +minute+ " / " +second);
    }
}