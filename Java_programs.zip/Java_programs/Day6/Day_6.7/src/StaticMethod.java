class Program
{
    private int num1;
    private int num2 ;
    private static int num3;

    static{
        Program.num3 =0;
    }
    Program()
    {
        this.num1 = 0;
        this.num2 = 0;
    }

    public void setNum1(int num1)
    {
        this.num1 = num1;
    }

    public void setNum1(int num2)
    {
        this.num2 = num2;
    }
    
    public static void setNum3(int num3)
    {
        Program.num3 = num3;
    }
}
class StaticMethod 
{
    public static void main(String[] args) 
    {
        Program pro = new Program();
        pro.setNum1(10);
        pro.setNum2(30);
        Program.setNum3(20);
    }   
}
