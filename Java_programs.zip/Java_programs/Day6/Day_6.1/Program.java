//Final modifier in java
class Program
{
    private static Scanner sc = new Scanner(System.in);
    public static void main(String[] args)
    {
        System.out.println("Number:");
        final int number = sc.nextInt();
        //number=10;
        System.out.println("Number is:" +number);
    }
    public static void main4(String[] args)
    {
        final int number = 10;
        //number=10;
        System.out.println("Number is:" +number);
    }
    public static void main3(String[] args)
    {
        final int number;
        number=10;
        System.out.println("Number is:" +number);
    }
    public static void main2(String[] args)
    {
        //final int number = 10;
        int number = 10;
        number = number + 15;
        System.out.println("Number is:" +number);
    }
    public static void main1(String[] args)
    {
        int number = 10;
        number = number + 15;
        System.out.println("Number is:" +number);
    }
}