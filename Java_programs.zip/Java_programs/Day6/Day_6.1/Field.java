// public class Test{
//     private int number;
//     public void showRecord()
//     {
//         System.out.println("Number:"+this.number);
//     }
// class Field
// {
//     public static void main(string[] args)
//     {
//         Test t = new Test();
//         t.showRecord();
//     }
// }


// class Test
// {
//     private final int number;
//     public void showRecord()
//     {
//         this.number = this.number+1;
//         System.out.print("Number:" +this.number);   
//     }
//     public void printRecord()
//     {
//         this.number = this.number+1;
//         System.out.println("Number:" +this.number);   
//     }
// }
// class Field
// {
//     public static void main(String[] args)
//     {
//         Test t = new Test();
//         t.showRecord();
//         t.printRecord();
//         t.printRecord();


//     }
// }


// class Test
// {
//     private final int number;
//     public Test()
//     {
//         this.number = 10;
//     }
//     public void showRecord()
//     {
//         //this.number = this.number+1;
//         System.out.print("Number:" +this.number);   
//     }
//     public void printRecord()
//     {
//         //this.number = this.number+1;
//         System.out.println("Number:" +this.number);   
//     }
// }
// class Field
// {
//     public static void main(String[] args)
//     {
//         Test t = new Test();
//         t.showRecord();
//         t.printRecord();
//         t.printRecord();


//     }
//}

class Test
{
    private final int NUMBER =10;
    public void showRecord()
    {
        System.out.println("Number is:"+this.NUMBER);
    }
    
    public void printRecord()
    {
        System.out.println("Number:"+this.NUMBER);
    }
}
class Field
{
    public static void main(String[] args)
    {
        Test t = new Test();
        t.showRecord();
        t.printRecord();
    }
}
