class Number
{
    private int num1 ;
    private int num2;
    private static int num3;
    private static int num4;

    public Number(int num1, int num2)
    {
        System.out.println("Constructor blocked of Number");
        this.num1 = num1;
        thiS.num2 = num2;
    }

    static
    {
        System.out.println("Static block of Number class");
        Number.num4 = 4030;
    }
}
class StaticMembers
{
    static{
        System.out.println("Static block of static class");
        Staticmembers.num3 = 299;
    }

    public StaticMembers()
    {
        System.out.println("Static constructor");
    }
    // public static void main(String[] args)
    // {
    //     Member m = new Member(10, 39);
    // }
}
