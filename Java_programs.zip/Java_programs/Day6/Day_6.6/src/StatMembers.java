class Members
{
    private int num1;
    private int num2;
    private static int num3;
    private static int num4;

    public Members(int num1, int num2)
    {
        this.num1 = num1;
        this.num2 = num2;
    }

    static{
        System.out.println("Static block");
        Members.num3=399;
        Members.num4 =290;
    }

    public void printRecord()
    {
        System.out.println("Numbers 1:" +this.num1);
        System.out.println("Numbers 2:" +this.num2);
        System.out.println("Number3:" +Members.num3);
        System.out.println("Number 4:"+Members.num4);
    }
}
class StatMembers 
{
    public static void main(String[] args)
    {
        Members m = new Members(10, 39);
        m.printRecord();
    }    
}
