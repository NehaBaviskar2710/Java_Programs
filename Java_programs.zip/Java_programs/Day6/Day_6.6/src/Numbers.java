class Test
{
    private int num1;
    private int num2;
    private int num3;

    public Test(int num1, int num2)
    {
        this.num1=num1;
        this.num2 =num2;
        this.num3 = 500;
    }
}

class Numbers 
{
    public static void main(String[] args)
    {
        Test t1 = new Test(10, 20);
        Test t2 = new Test(30, 40);
        Test t3 = new Test(50, 60);
    }
}
