class Test
{
    private int num1;
    private int num2;
    private static int num3;
    private static int num4;
    private static int num5;

    static
    {
        System.out.println("Static block");
        Test.num3 = 200;
    }

    public Test(int num1, int num2)
    {
        System.out.println("Constructor block");
        this.num1 = num1;
        this.num2 = num2;
    }
    static 
    {
        System.out.println("Static bloack");
        Test.num4 = 499;
    }
    public void printRecord()
    {
        System.out.println("Number1:"+this.num1);
        System.out.println("Number2:"+this.num2);
        System.out.println("Number3:"+Test.num3);
    }
    static
    {
        System.out.println("Static block");
        Test.num5 =599;
    }
}
class StaticClass 
{
    public static void main(String[] args)
    {
        Test t1 = new Test(10, 30);
        Test t2 = new Test(50, 70);
        Test t3 = new Test(60, 80);

        // t1.printRecord();
        // t2.printRecord();
        // t3.printRecord();
    }    
}
