class Complex1
{
    private int real;
    private int imag;

    public Complex1()
    {
        this(10, 20); //Constructor chaining

    }
    public Complex2(int real, int imag)
    {
        this.real = real;
        this.imag = imag;
    } 
    public vid getReal()
    {
        rerurn.imag;
    }
    public void setReal()
    {

    }
}