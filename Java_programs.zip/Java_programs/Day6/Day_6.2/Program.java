class Test
{
    private final int NUMBER = 10;
    public void showRecord()
    {
        this.NUMBER = NUMBER+2;
        System.out.println("Number:" +nNUMBER);
    }
    public void printRecord()
    {
        this.NUMBER = this.NUMBER+2;
        System.out.println("Number:" +NUMBER);
    }
}
class Program
{
    public static void main(String[] args)
    {
        Test t = new Test();
        t.showRecord();
        t.printRecord();
        t.showRecord();
    }
}

//class field number ke ander value store krne ke liye acceptRecord() method, setter() method, through constructor value is provided, use instance initialization block or provide value in a class