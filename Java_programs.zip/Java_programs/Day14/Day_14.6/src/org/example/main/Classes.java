package org.example.main;

abstract class Age
{
	public abstract void f1();
	public void f2()
	{
		System.out.println("A.f2");
	}
	public final void f3()
	{
		System.out.println("A.f3");	
	}
	
}
class Try extends Age
{
	@Override
	public void f1()
	{
		System.out.println("B.f1");
	}
	@Override
	public final void f2()
	{
		System.out.println("B.f2");
	}
}
final class C extends Try
{
	@Override
	public final void f1()
	{
		System.out.println("C.f1");
	}
}

public class Classes 
{
	public static void main(String[] args)
	{
		C c = new C();
		c.f1();
		c.f2();
		c.f3();
	}
}
