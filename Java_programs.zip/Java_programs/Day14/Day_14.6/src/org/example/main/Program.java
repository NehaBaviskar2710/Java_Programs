package org.example.main;

abstract class A
{
	public abstract void f1();
	public void f2()
	{
		System.out.println("A.f2");
	}
	public final void f3()
	{
		System.out.println("A.f3");
	}
}
class B extends A
{
	@Override
	public void f1()
	{
		System.out.println("B.f1");
	}
	
}
public class Program
{
	public static void main(String[] args)
	{
		A a = null;
		a.f1();
		a.f2();
		a.f3();
	}
}