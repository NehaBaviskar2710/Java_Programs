package org.example.main;

public @interface NoArgsConstructor {

}
