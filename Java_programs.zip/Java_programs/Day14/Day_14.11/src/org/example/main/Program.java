package org.example.main;

import lombok.Getter;
import lombok.Setter;
class Rectangle
{
	@Getter private float area;
	@Setter private float length;
	@Setter private float breadth;
	public void calculateArea()
	{
		this.area = this.length*this.breadth;
	}
}
class Circle
{
	@Getter private float area;
	@Setter private float radius;
	public void calculateArea()
	{
		this.area = (float)(Math.PI*Math.pow(this.radius, 2 ));
	}
}
class Triangle
{
	@Getter private float area;
	@Setter private float base;
	@Setter private float height;
	public void calculateArea()
	{
		this.area = 0.5f*this.base*this.height;
	}
}
public class Program
{
	public static void man(String[] args)
	{
		Triangle t = new Triangle();
		t.setBase(5.5f);
		t.setHeight(8.2f);
		t.calculateArea();
		System.out.println("Area of Triangle:"+t.getArea());
	}
	public static void main2(String[] args)
	{
		Circle c = new Circle();
		c.setRadius(10.5f);
		c.calculateArea();
		System.out.println("Area of Circle:"+c.getArea());
	}
	public static void main1(String args)
	{
		Rectangle rect = new Rectangle();
		rect.setLength(10.2f);
		rect.setBreadth(29.1f);
		rect.calculateArea();
		System.out.println("Area of Rectangle:"+rect.getArea());
	}
}