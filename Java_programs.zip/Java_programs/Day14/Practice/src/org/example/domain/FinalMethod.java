package org.example.domain;

class A1
{
	public void f1()
	{
		System.out.println("A.f1");
	}
	public final void f2()
	{
		System.out.println("A.f2");
	}
}
class B1 extends A1
{
	public void f3()
	{
		System.out.println("B.f3");
	}
	//@Override
	/*public final void f2()
	{
		
	}*/
}
public class FinalMethod 
{
	public static void main(String[] args)
	{
		B1 b = new B1();
		b.f1();
		b.f2();
		b.f3();
	}	
}
