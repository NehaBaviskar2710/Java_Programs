package org.example.domain;

class Super
{
	public static void display()
	{
		System.out.println("Super.display()");
	}
	
}
class Sub extends Super
{
	@Override
	public static void display()
	{
		System.out.println("Sub.display()");
	}
}
public class StaticOverride 
{
	public static void main(String[] args)
	{
		Sub s = new Sub();
		s.display();
	}
}
