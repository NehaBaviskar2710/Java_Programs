package org.example.domain;

abstract class N
{
	public abstract void f1();
	public abstract void f2();
	public abstract void f3();
}
abstract class E extends N
{
	@Override
	public void f1()
	{
		
	}
	@Override
	public void f2()
	{
		
	}
	@Override
	public void f3()
	{
		
	}
}
class H extends E
{
	@Override
	public void f1()
	{
		System.out.println("H.f1");
	}
}
class A2 extends E
{
	@Override
	public void f2()
	{
		System.out.println("A2.f2");
	}
}
class B2 extends E
{
	@Override
	public void f3()
	{
		System.out.println("B2.f3");
	}
}
public class AbstarctClass 
{
	public static void main(String[] args)
	{
		N n = null;
		n =new H();
		n.f1();
		n = new A2();
		n.f2();
		n = new B2();
		n.f3();
	}
}
