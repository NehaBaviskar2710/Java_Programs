package org.example.domain;

class Parent
{
	public void showRecord()
	{
		System.out.println("Parent.show()");
	}
}
class Child extends Parent
{
	@Override
	public void showRecord()
	{
		System.out.println("Child.show()");
	}
}
public class StaticMethod 
{
	public static void main(String[] args)
	{
		Child c = new Child();
		c.showRecord();
	}
}
