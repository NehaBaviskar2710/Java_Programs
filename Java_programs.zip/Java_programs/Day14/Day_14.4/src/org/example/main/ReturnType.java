package org.example.main;

class Parent
{
	public void printRecord()
	{
		System.out.println("Parent class");
	}
}
class Child extends Parent
{
	@Override
	public void printRecord()
	{
		System.out.println("Child class");
	}
	
}
public class ReturnType 
{
	public static void main(String[] args)
	{
		Child c = new Child();
		c.printRecord();
	}
}
