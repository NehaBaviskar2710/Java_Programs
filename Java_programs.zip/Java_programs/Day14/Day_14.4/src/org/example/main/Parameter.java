package org.example.main;

class A1{
}
class B1 extends A1{
}

class Test{
	public void printRecord()
	{
		System.out.println("Class Test");
	}
}
class Series extends Test
{
	@Override
	public void printRecord()
	{
		System.out.println("Class Series");
	}
}
public class Parameter 
{
	public static void main(String[] args)
	{
		Series s = new Series();
		s.printRecord();
	}
}
