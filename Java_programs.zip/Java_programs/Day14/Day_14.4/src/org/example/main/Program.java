package org.example.main;

import lombok.Data;

@Data

class Super
{
	public static void showRecord()
	{
		System.out.println("Super.showRecord()");
	}
}
class Sub extends Super
{
	public static void showRecord()
	{
		System.out.println("Sub.showRecord()");
	}
}
public class Program
{
	public static void main(String[] args)
	{
		Sub.showRecord();
	}
}