package org.example.main;

class A
{	
}
class B extends A
{
}

class Base
{
	
	public A printRecord()
	{
		System.out.println("Super.printRecord()");
		A a = new A();
	}
}
class Derived extends Base
{
	@Override
	public B printRecord()
	{
		System.out.println("Sub.printRecord()");
		B b = new B();
		return b;
	}
}
public class ReturnType2 
{
	public static void main(String[] args)
	{
		Derived d = new Derived();
		d.printRecord();
	}
}
