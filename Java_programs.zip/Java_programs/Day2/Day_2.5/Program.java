//Boxing : Process of converting value of variable of primitive type into non primitive type is called as boxing.
class Program{
    public static void main(String[] args){
        int number = 123;
        String str = Integer.toString(number);
        System.out.print("String is:" +str);
    }
}