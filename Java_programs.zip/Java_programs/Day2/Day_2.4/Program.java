class Program{
    public static void main(String[] args){
        int num1 = 10;
        int num2 = num1;
        System.out.print("Num2: "+num2);
    }
}