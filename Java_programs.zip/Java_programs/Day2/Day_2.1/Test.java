class Test
{
    private int num1;
    private static int num2;

    public void setNum1(int num1)
    {
        this.num1 = num1;
    }
    public static void setNum2(int num2)
    {
        this.num2 = num2;
    }
    public static void main(String[] args)
    {
        Test.setNum1(121);
    }
}