class Program{
    public static void main(String[] args){
        int number;
        number = 20;
        System.out.println(number);
    }
}