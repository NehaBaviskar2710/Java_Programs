class Program{
    public static void main(String[] args){
        String name = "Neha";
        int empid = 382784;
        double salary = 745923.45;
        System.out.print(name);
    } 

    public static void main(String[] args){
        int number=123;
        System.out.print("Hello ");
        System.out.print("World");
        System.out.print("!!");
        System.out.println("Python ");
        System.out.println("Program");
        System.out.println("!!");
        System.out.println("123");
        System.out.println(10 + 20);
        System.out.println("Sum:"+10 + 20);
        System.out.println("Sum:"+(10 + 20));
        System.out.println(number);
        System.out.println("Number is:"+number);
    }
}