class Text{
    public static void main(String[] args){
        String name = "Neha Baviskar";
        int empid = 238238;
        double salary =347785.33;
        String name2 = "Raj";
        int empid2 = 47563;
        double salary2 = 23890.234;
        System.out.printf(name +" "+ empid +" " +salary+ " ");
        System.out.printf(name2 +" "+ empid2 +" " +salary2 + " ");
    }
}