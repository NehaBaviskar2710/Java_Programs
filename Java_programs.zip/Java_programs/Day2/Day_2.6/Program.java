class Program{
    public static void main(String[] args){
        System.out.print("Hello" +args[0]);
    }
}