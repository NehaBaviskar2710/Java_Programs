/*
class Command{
    public static void main(String[] args){
        int num1 = Integer.parseInt(args[0]);
        System.out.print("Hello" +num1);
    }
}

class Command{
    public static void main(String[]args){
        String str = args[0];
        System.out.print("Hello" +str);
    }
}
*/

class Command{
    public static void main(String[] args){
        
    }
}