/*
class Boxing{
    public static void main(String[] args){
        int num1 = 293;
        String str =Integer.toString(num1);
        System.out.print("Given String is:" +str);
    }
}
*/
class Boxing{
    public static void main(String[] args){
        float num2 = 299.29f;
        String str1 = Float.toString(num2);
        System.out.println("After conversion of float to string:" +str1);
    }
}