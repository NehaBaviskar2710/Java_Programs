class Unboxing{
    public static void main(String[] args){
        String name = "132";
        int num1 = Integer.parseInt(name);
        System.out.print("Number is:" +num1); 
    }
}