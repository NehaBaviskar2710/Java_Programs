class Widening{
    public static void main(String[] args){
        int num1 = 123;
        double num2 = num1;
        System.out.print("Number is:" +num2);
    }
}