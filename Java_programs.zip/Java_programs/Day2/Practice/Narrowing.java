class Narrowing{
    public static void main(String[] args){
        double num1 = 3930.3d;
        int num2 = (int)num1;
        System.out.println("Number:" +num2);
    }
}