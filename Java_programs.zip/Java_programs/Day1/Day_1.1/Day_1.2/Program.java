class Program{
    public static void main(int number){
        System.out.println(number);
    }
    public static void main(String[] args){
        System.out.println("Program.main");
        Program.main(number:123);
    }
}