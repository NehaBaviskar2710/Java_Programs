package org.example.main;

class Person
{
	String name;
	int age;
	
	public Person()
	{
		this.name = " ";
		this.age = 0;
	}
	public Person(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	
	public void showRecord()
	{
		System.out.println("name:"+this.name);
		System.out.println("Age:"+this.age);
	}
}
class Employee extends Person
{
	int empid;
	float salary;
	
	public Employee()
	{
		this.empid = 0;
		this.salary = 0.0f;
	}
	
	public Employee(int empid, float salary)
	{
		this.empid = empid;
		this.salary = salary;
	}
	
	public void displayRecord()
	{
		System.out.println("Empid:"+this.empid);
		System.out.println("Salary:"+this.salary);
	}
}
class program
{
	public static void main(String[] args)
	{
		Person p = new Person();
		p.name = "neha";
		p.age = 20;
		//p.empid = 232;
		//p.salary = 1000000.88;
		p.showRecord();
	}
}