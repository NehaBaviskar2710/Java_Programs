package org.example.main;

class Person
{
	public void printRecord()
	{
		System.out.println("Person.printrecord()");
	}
}
class Employee extends Person
{
	@Override
	public void printRecord()
	{
		super.printRecord();
		System.out.println("Employee.printrecord()");
	}
}
class program
{
	public static void main(String[] args)
	{
		Employee emp  = new Employee();
		emp.printRecord();
	}
}