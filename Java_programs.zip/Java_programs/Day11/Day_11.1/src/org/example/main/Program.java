package org.example.main;

public class Program 
{
	public static void main(String[] arg)
	{
		
	}
}
