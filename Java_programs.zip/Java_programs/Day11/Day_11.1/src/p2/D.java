package p2;

import p1.A;
public class D extends A
{
	public void printNum1()
	{
		System.out.println("Num1:"+this.num1);
	}
}
