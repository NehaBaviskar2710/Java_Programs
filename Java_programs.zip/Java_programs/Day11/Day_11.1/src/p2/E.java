package p2;

public class E 
{
	public void displayNum1()
	{
		A a = new A();
		System.out.println("Number1:"=a.num1);
	}
}
