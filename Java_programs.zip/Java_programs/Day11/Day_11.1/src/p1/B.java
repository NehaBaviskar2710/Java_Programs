package p1;

public class B extends A
{
	int num1 ;
	public void printRecord()
	{
		System.out.println("Number1:"+num1);
	}
}
