package org.example.main;

import p1.A;
import p1.B;
import p1.C;
import p2.D;
public class Program 
{
	public static void main(String[] arsg)
	{
		D d = new D();
		d.printNum1();
	}
	public static void main3(String[] args)
	{
		C c = new C();
		c.printRecord();
	}
	public static void main2(String[] args)
	{
		B b = new B();
		b.printRecord();
	}
	public static void main1(String[] args)
	{
		A a = new A();
		a.showRecord();
	}
}
