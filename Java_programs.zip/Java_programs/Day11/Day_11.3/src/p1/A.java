package p1;

public class A 
{
	protected int num1= 10;
	public void showRecord()
	{
		System.out.println("Num1:"+this.num1);
	}
}
