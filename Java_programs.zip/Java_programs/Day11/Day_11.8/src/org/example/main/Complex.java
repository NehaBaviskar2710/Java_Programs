package org.example.main;

class ComplexData
{
	private int real;
	private int imag;
	
	public ComplexData()
	{
		this.real = 10;
		this.imag = 20;
	}
	
	public void setReal(int real)
	{
		real = real;
	}
	public void setImag(int imag)
	{
		imag = imag;
	}
	
	@Override
	public String toString()
	{
		return this.real+" "+this.imag;
	}
}
public class Complex
{
	public static void main(String[] args)
	{
		ComplexData c = new ComplexData();
		c.setReal(50);
		c.setImag(69);
	}
}
