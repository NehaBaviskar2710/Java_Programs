package in.demo.acts.domain;

import com.demo.highmark.domain.Person;
public class Employee extends Person
{
	
}
