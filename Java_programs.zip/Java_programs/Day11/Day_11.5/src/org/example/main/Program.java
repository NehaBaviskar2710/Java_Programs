package org.example.main;

class A
{
	public int num1;
	public A()
	{
		this.num1 = 10;
	}
	public int getNum1()
	{
		return this.num1;
	}
}
class B extends A
{
	
}
public class Program
{
	public static void main(String[] args)
	{
		B b = new B();
		System.out.println(b.num1);
	}
	public static void main1(String[] args)
	{
		A a = new A();
		System.out.println(a.num1);
		System.out.println( a.getNum1());
	}
}