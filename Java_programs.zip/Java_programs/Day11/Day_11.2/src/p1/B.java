package p1;

public class B extends A
{
	public void printRecord()
	{
		System.out.println("Number1:"+this.num1);
	}
}
