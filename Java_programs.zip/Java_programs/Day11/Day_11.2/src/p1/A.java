package p1;

public class A 
{
	int num1= 10;
	public void showRecord()
	{
		System.out.println("Num1:"+num1);
	}
}
