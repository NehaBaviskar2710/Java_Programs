package p1;

public class C 
{
	 public void printRecord()
	 {
		 A a = new A();
		 System.out.println("Num1:"+a.num1);
	 }
}
