package org.example.main;

class SubSuperValue
{
	int num1 = 10;
	int num2 = 20;

}
class SubValue extends SubSuperValue
{
	int num3 = 40;
	int num2 = 50;
	
	public void printRecord()
	{
		System.out.println("Num1:"+num1);
		System.out.println("Num2:"+num2);
		System.out.println("Numer3:"+num3);
		System.out.println("Num2:"+super.num2);
		System.out.println("Num3:"+this.num3);
		
	}
}
public class ValueClass 
{
	public static void main(String[] args)
	{
		
		SubValue  s  = new SubValue();
		s.printRecord();
	}
}
