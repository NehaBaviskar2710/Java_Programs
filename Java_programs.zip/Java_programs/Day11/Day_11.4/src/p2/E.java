package p2;

import p1.A;
class E 
{
	public void displayNum1()
	{
		A a = new A();
		System.out.println("Number1:"+a.num1);
	}
}
