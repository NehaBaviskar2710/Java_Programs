package org.example.main;

public class Institue {

}
