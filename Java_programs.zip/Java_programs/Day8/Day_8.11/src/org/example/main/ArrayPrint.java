package org.example.main;

import java.util.Scanner;
import org.example.main.Employee;
public class ArrayPrint
{
	static Scanner sc = new Scanner(System.in);
	private static void acceptRecord(Employee emp)
	{
		System.out.print("Name::");
		emp.setName(sc.nextLine());
		System.out.print("EmpId:");
		emp.setId(sc.nextInt());
		System.out.print("Salary:");
		emp.setSalary(sc.nextFloat());
	}
	private static void printRecord(Employee emp)
	{
		System.out.println(emp.toString());
	}
	public static void menuList()
	{
		System.out.println("0.Exit");
		System.out.println("1. Add new Employee");
		System.out.println("2. Find Employee");
		System.out.println("3. Remove Employee");
		System.out.println("4. Print Employee");
		return sc.nextInt();
	}
	public static void main()
	public static void main(String[] args)
	{
		Employee emp = new Employee();
		ArrayPrint.acceptRecord(emp);
		ArrayPrint.printRecord(emp);
	}
}