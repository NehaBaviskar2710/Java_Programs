package org.example.main;

import java.util.Scanner;
class ArrayAccept
{
	static Scanner sc = new Scanner(System.in);
	private static void acceptRecord(int[] arr)
	{
		for(int index=0; index<arr.length; index++)
			System.out.println(arr[index]+" ");
		System.out.println();
	}
	public static void main(String[] args)
	{
		int[] arr = new int[] {10, 20, 30, 40, 50};
		ArrayAccept.acceptRecord(arr);
	}
}
