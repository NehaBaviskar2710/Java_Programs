package org.example.main;

import java.util.Arrays;
class SizeOfArray
{
	public static void main(String[] args)
	{
		int[] arr = new int[] {10, 20, 30, 40, 50};
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}
}