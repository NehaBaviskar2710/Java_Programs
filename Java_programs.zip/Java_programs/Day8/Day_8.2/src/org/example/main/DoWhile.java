package org.example.main;

import java.util.Scanner;
class DoWhile
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[10];
		for(int element:arr)
		{
			System.out.println("Arr:"+element);
		}
	}
	public static void main3(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[5];
		for(int index= 0; index<5; index++)
		{
			System.out.println("ARR:"+index);
		}
	}
	public static void main2(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[10];
		int index = 0 ;
		while(index<10)
		{
			System.out.println("Arr:"+index);
			index = index+1;
		}
		
	}
	public static void main1(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = new int[5];
		int index = 0;
		System.out.println("Print the array:");
		do {
			
			System.out.println("ARR:"+index);
			index = index+1;
		}while(index<5);
	}
}