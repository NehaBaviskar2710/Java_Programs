package org.example.main;

import java.util.Scanner;
class Array
{
	static Scanner sc = new Scanner(System.in);
	private static void printRecord(int[] arr)
	{
		for(int index = 0; index<arr.length; index++)
		{
			System.out.print(arr[index] +" ");
		}
		System.out.println();
	}
	public static void main(String[] args)
	{
		int[] arr1 = new int[] {10, 20, 30, 40, 50};
		Array.printRecord(arr1);
		
		int[] arr2 = new int[] {10, 20, 30, 40, 50,60,70};
		Array.printRecord(arr2);
		
		int[] arr3 = new int[] {10, 20, 30};
		Array.printRecord(arr3);
	}
}