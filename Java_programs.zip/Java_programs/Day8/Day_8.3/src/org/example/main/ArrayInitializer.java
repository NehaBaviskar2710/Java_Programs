package org.example.main;

import java.util.Scanner;
class ArrayInitializer
{
	public void printRecord()
	//private static void printRecord()
	{
		int[] arr = {10, 20, 30, 40, 50};
		for(int index = 0; index<5; index++)
		{
			System.out.println(arr[index]);
		}
	}
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args)
	{
		//ArrayInitializer.printRecord();
		ArrayInitializer a = new ArrayInitializer();
		a.printRecord();
	}
	public static void main2(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] arr = {10, 20, 30, 40, 50};
		for(int index=0; index<5; index++)
		{
			System.out.println("Array Elements:"+arr[index]);
		}
	}
	public static void main1(String[] args)
	{
		//Array initialize in java
		//int[] arr = new int[3];
		//int[] arr = {10, 20, 30};
		//int[] arr = new int[]{10, 20, 30};
		
	}
}