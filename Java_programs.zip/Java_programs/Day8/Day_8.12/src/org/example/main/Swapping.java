package org.example.main;

class Swapping
{
	private static void swap(int a, int b)
	{
		int temp = a;
		a = b; 
		b = temp;
	}
	public static void main(String[] args)
	{
		int x = 10; 
		int y = 20;
		Swapping.swap(x, y);
		System.out.println("X:"+x);
		System.out.println("Y:"+y);
		
	}
}