package org.example.main;

import java.util.Scanner;
public class Program
{
	private static Scanner sc = new Scanner(System.in);
	private static void acceptRecord(int[][] arr)
	{
		for(int row = 0; row<arr.length; row++)
		{
			for(int col = 0; col<arr[row].length; col++)
			{
				System.out.print("Enter number; ");
				arr[row][col] = sc.nextInt();
			}
		}
	}
	private static void printRecord(int[][] arr)
	{
		for(int row = 0; row<arr.length; row++)
		{
			for(int col = 0; col<arr[row].length; col++)
			{
				System.out.print(arr[row][col]+ " ");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args)
	{
		int[][] arr = new int[4][3];
		//System.out.println(arr.length);
		Program.acceptRecord(arr);
		Program.printRecord(arr);
	}
	
	public static void main5(String[] args)
	{
		int[][] arr = new int[4][3];
		//System.out.println(arr.length);
		for(int row = 0; row<arr.length; row++)
		{
			for(int col = 0; col<arr[row].length; col++)
			{
				System.out.print("Enter number; ");
				arr[row][col] = sc.nextInt();
			}
			System.out.println();
		}
	}
	
	public static void main4(String[] args)
	{
		int[][] arr = new int[4][3];
		System.out.println(arr[0][0]+" "+arr[0][1]+" "+arr[0][2]);
		System.out.println(arr[1][0]+" "+arr[1][1]+" "+arr[1][2]);
		System.out.println(arr[2][0]+" "+arr[2][1]+" "+arr[2][2]);
		System.out.println(arr[3][0]+" "+arr[3][1]+" "+arr[3][2]);
	}
	public static void main3(String[] args)
	{
		int[][] arr = new int[4][3];
	}
	public static void main2(String[] args)
	{
		//insttantiation
		int arr[][] = null;
		arr = new int[4][3];
		
	}

	public static void main1(String[] args)
	{
		//Reference declaration
		int arr1[][] = null;
		int[] arr2[] = null;
		int[][] arr3 = null;
	}
}