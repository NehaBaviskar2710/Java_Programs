package org.example.main;

class ArrayIn
{
	private static void printRecord(int[] arr)
	{
		if(arr!=null)
		{
			for(int element:arr)
				System.out.println(element+" ");
		}
		System.out.println();
	}
	
	public static void main(String[] args)
	{
		int[] arr = new int[] {10, 20, 30, 40, 50};
		ArrayIn.printRecord(arr);
	}
	
}
