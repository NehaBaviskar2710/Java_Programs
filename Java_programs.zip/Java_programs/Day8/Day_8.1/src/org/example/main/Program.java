package org.example.main;

import java.util.Scanner;
//
//class Program
//{
//	static Scanner sc = new Scanner(System.in);
//	public static void main(String[] args)
//	{	
//		System.out.println("Enter array size:");
//		int size = sc.nextInt();
//		
//	}
//	public static void main3(String[] args)
//	{
//		//array instantiation
//		int[] arr = new int[3];
//	}
//	public static void main2(String[] args)
//	{
//		//array instance declaration
//		int[] arr = null;
//		arr = new int[3];
//	}
//	public static void main1(String[] args)
//	{
//		//array reference declaration
//		int arr1[] = null;
//		int[] arr1 = null;		
//	}
//}
class Program
{
	Scanner sc = new Scanner(System.in);
	public static void main(String[] args)
	{
		int[] arr = new int[5];
		int  index = 0;
		do {
			System.out.println("arr:"+index);
			index = index + 1;
		}while(index<5);
	}
	public static void main1(String[] args)
	{
		//Scanner sc = new Scanner(System.in);
		//int[] arr = new int[3];
		double[] arr = new double[5];
		System.out.println("Array index:");
		System.out.println("arr[0]:"+arr[0]);
		System.out.println("arr[1]:"+arr[1]);
		System.out.println("arr[2]:"+arr[2]);
		System.out.println("arr[3]:"+arr[3]);
		System.out.println("arr[4]:"+arr[4]);
	}
}