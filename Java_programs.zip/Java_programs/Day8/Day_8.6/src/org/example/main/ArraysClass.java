package org.example.main;

import java.util.Arrays;
class ArraysClass
{
	public static void main(String[] args)
	{
		int[] arr = new int[] {10, 20, 30};
		System.out.println(Arrays.toString(arr));
	}
	public static void main1(String[] args)
	{
		int[] arr = new int[] {10, 20, 30};
		String str = Arrays.toString(arr);
		System.out.println(str);
	}
}