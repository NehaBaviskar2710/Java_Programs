package org.example.main;

import java.util.Scanner;
class AllPrimitive
{
	public static void main(String[] args)
	{
		boolean[] arr1 = new boolean[3];
		System.out.println(arr1.toString());
		
		byte[] arr2 = new byte[3];
		System.out.println(arr2.toString());
		
		char[] arr3 = new char[3];
		System.out.println(arr3.toString());
		
		short[] arr4 = new short[3];
		System.out.println(arr4.toString());
		
		int[] arr5 = new int[3];
		System.out.println(arr5.toString());
		
		float[] arr6 = new float[3];
		System.out.println(arr6.toString());
		
		double[] arr7 = new double[3];
		System.out.println(arr7.toString());
		
		long[] arr8 = new long[3];
		System.out.println(arr8.toString());
		
		String[] arr9 = new String[3];
		System.out.println(arr9.toString());
	}
}
