package org.example.main;

class ArrayElement
{
	public static void main3(String[] args)
	{
		int[] arr = new int[] {10, 20, 30};
		int element = arr[arr.length];
		System.out.println(element);
	}
	
	public static void main2(String[] args)
	{
		int[] arr = new int[] {10, 20, 30};
		int element = arr[1];
		System.out.println(element);
	}
	
	public static void main1(String[] args)
	{
		int[] arr = new int[] {10, 20, 30};
		int element = arr[-2];
		System.out.println(element);
	}
}
