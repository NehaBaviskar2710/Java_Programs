package org.example.domain;

import org.example.domain.Employee;
public class EmployeeInfo
{
	private static Employee[] getArray()
	{
		Employee[] arr = new Employee[5];
		arr[0] = new Employee("Neha", 1202, 900000.49f);
		arr[1] = new Employee("Jay", 1923, 900000.99f);
		arr[2] = new Employee("Paresh", 2398, 900000.87f);
		arr[3] = new Employee("Kimay", 2022, 900000.12f);
		arr[4] = new Employee("Ujwal", 1932, 900000.29f);
		return arr;
	}
	private static void printRecord(Employee[] arr)
	{
		for(Employee emp : arr)
			System.out.println(emp.toString());
	}
	public static void main(String[] args)
	{
		Employee[] arr = EmployeeInfo.getArray();
		EmployeeInfo.printRecord(arr);
	}
	public static void main2(String[] Aargs)
	{
		Employee[] arr = EmployeeInfo.getArray();
		for(Employee emp : arr)
		{
			System.out.println(emp.toString());
		}
	}
	public static void main1(String[] args)
	{
		Employee[] arr = new Employee[5];
		arr[0] = new Employee("Neha", 1202, 900000.49f);
		arr[1] = new Employee("Jay", 1923, 900000.99f);
		arr[2] = new Employee("Paresh", 2398, 900000.87f);
		arr[3] = new Employee("Kimay", 2022, 900000.12f);
		arr[4] = new Employee("Ujwal", 1932, 900000.29f);
		
	}
}
