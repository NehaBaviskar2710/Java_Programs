//package org.example.main;
//
//import java.time.LocalDate;
//import java.util.Arrays;
//class Date
//{
//	int day;
//	int month;
//	int year;
//	
//	public Date()
//	{
//		LocalDate ld = LocalDate.now();
//		this.day = ld.getDayOfMonth();
//		this.month = ld.getMonthValue();
//		this.year = ld.getYear();
//	}
//	
//	public Date(int day, int month, int year)
//	{
//		this.day = day;
//		this.month = month;
//		this.year = year;
//	}
//	
//	@Override
//	public String toString()
//	{
//		System.out.println(this.day+" / "+this.month+" / "+this.year);
//	}
//}
//class ArrayReference
//{
//	public static void main(String[] args)
//	{
//		Date[] arr = new Date[3];
//		for(int index=0; index<arr.length; index++)
//			arr[index] = new Date();
//		for(int index=0; index<arr.length; index++)
//		{
//			System.out.println(arr[index].toString());
//		}
//	}
//	public static void main3(String[] args)
//	{
//		Date[] arr = new Date[3];
//		arr[0]  = new Date();
//		arr[1] = new Date();
//		arr[2] = new Date();
//		for(int index=0; index<arr.length; index++)
//		{
//			System.out.println(arr[index].toString());
//		}
//	}
//	public static void main2(String[] args)
//	{
//		Date[] arr = new Date[3];
//		for(int index=0; index<arr.length; index++)
//		{
//			System.out.println(arr[index].toString());
//		}
//	}
//	public static void main1(String[] args)
//	{
//		Date[] arr = new Date[3];
//		System.out.println(Arrays.toString(arr));
//	}
//}