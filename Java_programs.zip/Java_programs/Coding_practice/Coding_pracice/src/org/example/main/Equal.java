package org.example.main;

class Equal 
{
	static int num1 = 10;
	static int num2 = 20;
	
	public static void main(String[] args)
	{
		if(num1 == num2)
		{
			System.out.println("Equal");
		}
		else
		{
			System.out.println("Not Equal");
		}
	}
}
