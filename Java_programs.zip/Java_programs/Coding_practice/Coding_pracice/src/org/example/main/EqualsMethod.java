package org.example.main;

class CheckEqual
{
	private String name;
	private int age;
	
	public CheckEqual(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	public void displayRecord()
	{
		System.out.println("Name:"+this.name+"Age:"+this.age);
	}
}
public class EqualsMethod 
{
	public static void main(String[] args)
	{
		CheckEqual c = new CheckEqual("Rashi", 39);
		c.displayRecord();
	}
}
