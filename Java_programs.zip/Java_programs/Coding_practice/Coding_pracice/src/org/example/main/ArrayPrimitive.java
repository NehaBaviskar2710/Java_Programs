package org.example.main;

import java.util.Arrays;
public class ArrayPrimitive 
{
	public static void main(String[] args)
	{
		int[] arr = new int[] {30, 10, 90, 68, 29, 20};
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}
}
