package org.example.main;

import java.util.Scanner;

public class StackProgram 
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		
		// Accepting input from the user
        System.out.print("Enter a stack: ");
        String userInput = sc.nextLine();

        // Displaying the input
        System.out.println("You entered: " + userInput);

        sc.close();
	}
}
