package org.example.main;

class Person1
{
	String name;
	int age;
	
	public Person1()
	{
		name = "";
		age = 0;
	}
	public Person1(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	public void printRecord()
	{
		System.out.println("Name:"+this.name);
		System.out.println("Age:"+this.age);
	}

}
class Employee1 extends Person1
{
	int empid;
	float salary;
	
	public Employee1()
	{
		super();
		empid = 0;
		salary = 0.0f;
	}
	public Employee1(int empid, float salary)
	{
		this.empid = empid;
		this.salary = salary;
	}
	public void showRecord()
	{
		System.out.println("Empid:"+this.empid);
		System.out.println("Salary:"+this.salary);
	}
}
public class SuperMembers 
{
	public static void main(String[] args)
	{
		Employee1 emp = new Employee1();
		emp.name = "Neha";
		emp.age  =20;
		emp.printRecord();
		emp.showRecord();
		
	}
}
