package org.example.main;

public class Boxing 
{
	public static void main(String[] args)
	{
		int num = 20;
		Object o = num;
		System.out.println("Number:"+o);
	}
	public static void main1(String[] args)
	{
		int number = 10;
		String str = String.valueOf(number);
		System.out.println("Number:"+str);
		
		Integer i = Integer.valueOf(number);
		System.out.println("Number:"+i);

	}
}
