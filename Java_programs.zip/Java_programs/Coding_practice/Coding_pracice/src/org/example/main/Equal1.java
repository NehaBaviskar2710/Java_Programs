package org.example.main;

class Family
{
	String name;
	int age;
	
	public Family(String name, int age)
	{
		this.name = name;
		this.age = age;
	}
	public void printRecord()
	{
		System.out.println("Name:"+this.name+"Age:"+this.age);
	}
}
class Equal1 
{
	public static void main(String[] args)
	{
		Family emp1 = new Family("Neha",20);
		Family emp2 = new Family("Jay", 17);
		emp1.printRecord();
		emp2.printRecord();
		if(emp1 == emp2)
		{
			System.out.println("Equal");
		}
		else 
		{
			System.out.println("Not Equal");
		}
	}
}