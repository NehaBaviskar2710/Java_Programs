package org.example.main;

class A1
{
	public void printRecord()
	{
		System.out.println("A.printRecord()");
	}
	
}
class B1 extends A1
{
	public void printRecord()
	{
		System.out.println("B.printRecord()");
	}
}
public class Override 
{
	public static void main(String[] args)
	{
		A1 a = new B1();
		a.printRecord();
		B1 b = (B1)a;
		b.printRecord();
	}
}
