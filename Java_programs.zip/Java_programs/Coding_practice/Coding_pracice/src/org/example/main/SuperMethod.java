package org.example.main;

class Parent
{
	public void showRecord()
	{
		System.out.println("P.showRecord()");
	}
	public void printRecord()
	{
		System.out.println("P.printRecord()");
	}
}
class Child extends Parent
{
	public void displayRecord()
	{
		System.out.println("C.displayRecord()");
	}
	public void printRecord()
	{
		System.out.println("C.printRecord()");
	}
}
public class SuperMethod 
{
	public static void main(String[] args)
	{
		Child c = new Child();
		c.showRecord();
		c.displayRecord();
		c.printRecord();
		
	}
}
