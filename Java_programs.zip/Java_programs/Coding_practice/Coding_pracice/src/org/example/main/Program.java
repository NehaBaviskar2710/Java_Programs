package org.example.main;

class Person
{
	private String name;
	private int empid;
	
	public Person(String name, int empid)
	{
		name = this.name;
		empid = this.empid;
	}
	
	public void printRecord()
	{
		
	}
}

class Employee extends Person
{
	
}
public class Program 
{
	public static void main(String[] args)
	{
		
	}
}
