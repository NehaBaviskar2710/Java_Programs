package org.example.main;

class A
{
	int num1 = 10;
	int num2 = 20;
}
class B extends A
{
	int num2 = 40;
	int num3 = 50;
	
	public void printRecord()
	{
		System.out.println("Number 1:"+super.num1);
		System.out.println("Number 2:"+super.num2);
		System.out.println("Number 3:"+num2);
		System.out.println("Number 4:"+num3);
	}
}
public class SuperVariable 
{
	public static void main(String[] args)
	{
		B b = new B();
		b.printRecord();
	}
}
