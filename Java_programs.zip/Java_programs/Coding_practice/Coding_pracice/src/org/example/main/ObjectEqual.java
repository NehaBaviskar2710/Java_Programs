package org.example.main;

class SuperObject
{
	private String name;
	private int age;
	private int id;
	
	public SuperObject(String name, int age, int id)
	{
		this.name= name;
		this.age = age;
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if(obj != null)
		{
			SuperObject super = (SuperObject)obj;
			
		}
	}
	public void showRecord()
	{
		System.out.println("Name:"+this.name+"Age:"+this.age+"Id:"+this.id);
	}
	
}
public class ObjectEqual 
{
	public static void main(String[] args)
	{
		SuperObject s = new SuperObject("Rita",40, 1233);
		SuperObject o = new SuperObject("Janvi", 30, 3392);
		s.showRecord();
		o.showRecord();
	}
}
