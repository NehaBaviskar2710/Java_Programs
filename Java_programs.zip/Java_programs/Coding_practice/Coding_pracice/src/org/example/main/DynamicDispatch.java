package org.example.main;

class Person2
{
	public void printRecord()
	{
		System.out.println(Person2.)
	}
}
class Employee2;
{
	
}
public class DynamicDispatch 
{

	public static void main(String[] args)
	{
		
	}
}
