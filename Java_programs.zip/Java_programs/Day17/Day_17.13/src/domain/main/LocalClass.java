package domain.main;

public class LocalClass {

}
