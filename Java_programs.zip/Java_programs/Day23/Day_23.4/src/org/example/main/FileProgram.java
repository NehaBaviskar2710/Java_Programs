package org.example.main;

import java.io.File;
import java.io.IOException;

public class FileProgram 
{
	public static void main(String[] args)
	{
		try 
		{
			String pathname = "Sample";
			File file = new File(pathname);
		
			if(file.exists()) {
				System.out.println("Directory already exists");
			}
			else
			{
				boolean status = file.delete();
				System.out.println("Directory deletion successful");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main4(String[] args)
	{
		try 
		{
			String pathname = "Sample";
			File file = new File(pathname);
		
			if(file.exists()) {
				System.out.println("Directory already exists");
			}
			else
			{
				boolean status = file.mkdir();
				System.out.println("Directory creation successful");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main3(String[] args)
	{
		try 
		{
			String pathname = "Large.text";
			File file = new File(pathname);
		
			if(!file.exists())
				System.out.println("File is already exists");
			else
			{
				boolean status = file.delete();
				System.out.println("File deletion successfully");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main2(String[] args)
	{
		try 
		{
			String pathname = "Sample.txt";
			File file = new File(pathname);
			if(file.exists())
				System.out.println("File is already exist");
			else
			{
				boolean status = file.createNewFile();
				System.out.println("File crreation is successful");
			}
		}catch(IOException e)
		{
			e.printStackTrace();
		}
}
	public static void main1(String[] args)
	{
		String pathname = "Sample.txt";
		File file = new File(pathname);
	}
}
