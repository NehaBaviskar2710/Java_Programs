package org.example.domain;

public class Account 
{
	
}
