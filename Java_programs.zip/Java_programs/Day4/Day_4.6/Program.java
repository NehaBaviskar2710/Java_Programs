class Program{
    static void sum(int num1, float num2){
        float result = num1 + num2;
        System.out.println("Result: " +result);
    }
    static void sum(float num1, int num2){
        float result = num1 + num2;
        System.out.println("Result: " +result);
    }
    public static void main(String[] args){
        Program.sum(10, 39.32f);
        Program.sum(329.3f, 29);
    }
}