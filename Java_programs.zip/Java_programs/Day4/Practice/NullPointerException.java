import java.util.Scanner;
class Student{
    String stud_name;
    int stud_id;

    void accept(){
        Scanner scan = new Scanner(System.in);
        System.out.println("Accept Student Information:");
        stud_name = scan.nextLine();
        stud_id = scan.nextInt();
    }
}
class NullPointerException{
    public static void main(String[] args){
        Student sc = new Student();
        sc.accept();
        
    }
        

}