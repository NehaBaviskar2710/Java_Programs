class Program{
    static int sum(int num1, int num2){
        int result = num1 + num2;
        return result;
    }
    public static void main(String[] args){
        Program.sum(10, 20);
    }
}