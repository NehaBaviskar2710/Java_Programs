import java.util.Scanner;
class Employee{
    String name;
    int empid;
    float salary;

    void acceptRecord(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Name:");
        this.name = sc.nextLine();
        System.out.println("Employee id:");
        this.empid = sc.nextInt();
        System.out.println("Salary:");
        this.salary = sc.nextFloat();
    }
    void printRecord(){
        System.out.println(name + " " + empid + " " + salary);
    }
}
class Program{
    public static void main(String[] args){
        //Employee emp = null; comes NullPointerException
        Employee emp = new Employee();
        emp.acceptRecord();
        emp.printRecord();

    }
}