//WAP to accept Employee information and printon console.
class Employee{
    String name;
    int empid;
    float salary;
}
class Program{
    public staic void main(String[] args){
        Employee emp = new Employee();
    }
}