package example.main.com;

import java.util.Scanner;
class Shape
{
	protected float area;
	
	public Shape()
	{
		
	}
	public float getArea()
	{
		return this.area;
	}
}
class Rectangle extends Shape
{
	//private float area;
	private float length;
	private float breadth;
	
	public Rectangle()
	{
		
	}
	
//	public void acceptRecord()
//	{
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Lenght:");
//		this.length = sc.nextFloat();
//		System.out.println("Breadth:");
//		this.breadth = sc.nextFloat();
//	}
	public void setLength(float length)
	{
		this.length = length;
	}
	public void setBreadth(float breadth)
	{
		this.breadth = breadth;
	}
	public void calculte()
	{
		this.area = this.length*this.breadth;
	}

}
class Circle extends Shape
{
	
	private float radius;
	
	public Circle()
	{
		
	}
	
//	public void acceptRecord()
//	{
//		Scanner sc = new Scanner(System.in);
//		System.out.println("Radius:");
//		this.radius = sc.nextInt();
//	}
	public void setRadius(float radius)
	{
		this.radius = radius;
	}
	public void calculate()
	{
		this.area = (float)(Math.PI*Math.pow(radius, 2));
	}

}

class RectangleTest
{
	private Rectangle rect = new Rectangle();
	
	private static Scanner sc = new Scanner(System.in);
	public void acceptRecord()
	{
		System.out.println("Length:");
		this.rect.setLength(sc.nextFloat());
		System.out.println("Breadth:");
		this.rect.setBreadth(sc.nextFloat());
		
		this.rect.calculate();
	}
	public void printRecord()
	{
		System.out.println("Area:"+this.rect.getArea());
	}
}
class CircleTest
{
	Circle circle = new Circle();
	
	private static Scanner sc = new Scanner(System.in);
	public void acceptRecord()
	{
		System.out.println("Radius:");
		this.circle.setRadius(sc.nextFloat());
		
		this.circle.calculate();
	}
	public void printRecord()
	{
		System.out.println("Area:"+this.circle.getArea());
	}
}
public class CircleRectangle 
{
	public static void main2(String[] args)
	{
		Rectangle r = new Rectangle();
		r.setLength(10.2f);
		r.setBreadth(20.2f);
		System.out.println("Area:" +r.getArea());
	}
	
	public static void main1(String[] args)
	{
		Circle c = new Circle();
		c.setRadius(2.5f);
		System.out.println("Area:"+c.getArea());
	}
}
