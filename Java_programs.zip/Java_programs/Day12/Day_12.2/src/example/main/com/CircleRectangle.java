package example.main.com;

import java.util.Scanner;
class Rectangle
{
	private float area;
	private float length;
	private float breadth;
	
	public void acceptRecord()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Lenght:");
		this.length = sc.nextFloat();
		System.out.println("Breadth:");
		this.breadth = sc.nextFloat();
	}
	public void calculte()
	{
		this.area = this.length*this.breadth;
	}
	public void printRecord()
	{
		System.out.println("Area:"+this.area);
	}
}
public class CircleRectangle 
{
	public static void main(String[] args)
	{
		Rectangle r = new Rectangle();
		r.acceptRecord();
		r.calculte();
		r.printRecord();
	}
}
