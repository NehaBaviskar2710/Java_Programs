package org.example.demo;

public class Program 
{
	public static void main(String[] args)
	{
		int num1 = 10;
		int num2 = 10;
		//if(num1.equals(num2))
		if(num1 == num2)
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
}
