package org.example.demo;

class Employee
{
	private String name;
	private int empid;
	private float salary;
	public Employee(String name, int empid, float salary) 
	{
		this.name = name;
		this.empid = empid;
		this.salary = salary;
	}
	
}
public class EqualsMethod 
{
	public static void main(String[] args)
	{
		Employee emp1 = new Employee("neha", 123, 1000000.20f);
		Employee emp2 = new Employee("riya", 124, 1000000.2f);
		if(emp1.equals(emp2))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
	public static void main1(String[] args)
	{
		Employee emp1 = new Employee("neha", 123, 1000000.20f);
		Employee emp2 = new Employee("riya", 124, 1000000.2f);
		if(emp1 == emp2)
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
}
