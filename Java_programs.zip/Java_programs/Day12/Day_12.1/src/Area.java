
public class Area {

}
