package example.main.com;

public class Area 
{
	public static void main(String[] args)
	{
		float radius = 12.3f;
		float area = (float)(Math.PI*Math.pow(radius,  2));
		System.out.println("Area of rectangle:"+area);
		
	}
	public static void main1(String[] args)
	{
		float length = 12.6f;
		float breadth = 10.2f;
		float area = length*breadth;
		System.out.println("Area of Rectangle is:"+area);
	
	}
}
