package example.main.com;

import java.util.Scanner;
class Shape
{
	protected float area;
	
	public Shape()
	{
		
	}
	public void printRecord()
	{
		System.out.println("Area:"+this.area);
	}
}
class Rectangle extends Shape
{
	//private float area;
	private float length;
	private float breadth;
	
	public void acceptRecord()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Lenght:");
		this.length = sc.nextFloat();
		System.out.println("Breadth:");
		this.breadth = sc.nextFloat();
	}
	public void calculte()
	{
		this.area = this.length*this.breadth;
	}
//	public void printRecord()
//	{
//		System.out.println("Area:"+this.area);
//	}
}
class Circle extends Shape
{
	//private float area;
	private float radius;
	
	public void acceptRecord()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Radius:");
		this.radius = sc.nextInt();
	}
	public void calculate()
	{
		this.area = (float)(Math.PI*Math.pow(radius, 2));
	}
//	public void printRecord()
//	{
//		System.out.println("Area :"+this.area);
//	}
}
public class CircleRectangle 
{
	public static void main1(String[] args)
	{
		Rectangle r = new Rectangle();
		r.acceptRecord();
		r.calculte();
		r.printRecord();
	}
	
	public static void main(String[] args)
	{
		Circle c = new Circle();
		c.acceptRecord();
		c.calculate();
		c.printRecord();
	}
}
