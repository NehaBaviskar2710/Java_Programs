package org.example.demo;

class Employee
{
	private String name;
	private int empid;
	private float salary;
	public Employee(String name, int empid, float salary) 
	{
		this.name = name;
		this.empid = empid;
		this.salary = salary;
	}
	@Override
	public boolean equals(Object obj)
	{
		Employee other = (Employee)obj;
		//if(this.name == other.name && this.empid ==other.empid && this.salary == other.salary)
		if(this.empid == other.empid)	
			return true;
		return false;
	}
}
public class EqualsMethod 
{
	public static void main(String[] args)
	{
		Employee emp1 = new Employee("neha", 123, 1000000.20f);
		Employee emp2 = new Employee("riya", 124, 1000000.2f);
		if(emp1.equals(emp2))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
	public static void main1(String[] args)
	{
		Employee emp1 = new Employee("neha", 123, 1000000.20f);
		Employee emp2 = new Employee("riya", 124, 1000000.2f);
		if(emp1 == emp2)
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
	}
}
