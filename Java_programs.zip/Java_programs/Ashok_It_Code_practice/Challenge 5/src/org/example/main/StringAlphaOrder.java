package org.example.main;
import java.util.Arrays;
public class StringAlphaOrder 
{
	public static void main(String[] args)
	{
		//Approach 1
		String str = "neha";
		
		char arr[] = str.toCharArray();
		char temp;
		for(int i = 0; i<arr.length; i++)
		{
			for(int j = i+1; j<arr.length; j++)
			{
				if(arr[i]>arr[j])
				{
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		System.out.println(new String(arr));
		
		//Approach 2
		String str1 = "Java";
		char[] arr1 = str1.toCharArray();
		Arrays.sort(arr1);
		System.out.println(arr1);
	}
}
