package org.example.main;

public class RemoveWhiteSpace 
{
	public static void main(String[] args)
	{
		String str = " j a va st a r ";
		
		String str1 = str.trim();
		System.out.println(str1);
		
		String str2 = str.replaceAll("\\s","");
		System.out.println(str2);
	}
}
