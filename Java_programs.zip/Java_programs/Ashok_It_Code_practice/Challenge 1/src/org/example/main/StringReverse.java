package org.example.main;

//public class StringReverse 
//{
//	public static void main(String[] args)
//	{
//		String str = "Hello";
//		
//		//Approach 1
//		char[] chararr = str.toCharArray();
//		
//		for(int i = chararr.length-1; i>=0; i--)
//		{
//			System.out.println(chararr[i]);
//		}
//		
//		System.out.println(" ");
//		
//		//Approach 2
//		for(int i=str.length()-1; i>=0; i--)
//		{
//			System.out.println(str.charAt(i));
//		}
//		
//		System.out.println(" ");
//		
//		//Approach 3
//		StringBuilder sb = new StringBuilder(str);
//		System.out.println(sb.reverse());
//		
//		System.out.println(" ");
//		
//		//Approach 4
//		StringBuffer sbf = new StringBuffer(str);
//		System.out.println(sbf.reverse());
//	}
//}

public class StringReverse
{
	public static void main(String[] args)
	{
		//Approach-1
		String str = "Hello";
		
		char[] chararr = str.toCharArray();
		
		for(int i = chararr.length-1; i>=0; i--)
		{
			System.out.println(chararr[i]);
		}
		
		//Approach-2
		for(int i=str.length()-1; i>=0; i--)
		{
			System.out.println(str.charAt(i));
		}
		
		//Approach-3
		StringBuffer sb = new StringBuffer(str);
		System.out.println(sb);
		
		//Approach4
		StringBuilder sf = new StringBuilder(str);
		System.out.println(sf);
	}
}