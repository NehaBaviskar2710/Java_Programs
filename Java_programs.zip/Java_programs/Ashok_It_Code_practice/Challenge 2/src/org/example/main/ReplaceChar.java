package org.example.main;

public class ReplaceChar 
{
	public static void main(String[] args)
	{
		String str = "$ja!va$&s+%ar";
		
		String str1= str.replaceAll("[^a-zA-Z0-9]","");
		System.out.println(str1);
	}
}
