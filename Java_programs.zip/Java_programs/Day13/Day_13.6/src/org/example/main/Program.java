package org.example.main;

abstract class A
{
	public abstract void print();
}
class B extends A
{
	@Override
	public void print()
	{
		for(int count = 0; count<=10; count++)
			System.out.println("Count:"+count);
			Thread.sleep(250);
	}
}
public class Program
{
	public static void main(String[] orgs)
	{
		A a = new B();
		a.print();
	}
}