package org.example.main;

import java.util.Scanner;
import java.io.IOException;
import java.io.Closeable;
class Test implements Closeable
{
	private Scanner sc ;
	
	public Test()
	{
		this.sc = new Scanner(System.in);
	}
	
	@Override
	public void close() throws IOException
	{
		this.sc.close();
	}
}

public class Program
{
	public static void main(String[] args)
	{
		try
		{
			Test t = new Test();
			
			t.close();
		}catch (IOException e) 
		{
			 // TODO Auto-generated catch block
			 e.printStackTrace();
		}
	}
}