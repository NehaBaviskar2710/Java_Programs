package org.example.main;

import java.util.Scanner;
public class Program
{
	private static Scanner sc = new Scanner(System.in);
	
	public sttaic int menuList()
	{
		System.out.println("")
	}
	public static void main(String[] args)
	{
		//Program p = new Program();
		//Program.showRecord();
		try {
			Program.displayRecord();
		}catch (InterruptedExcepton e) {
			e.printStackTrace();
		}
		
	}
}