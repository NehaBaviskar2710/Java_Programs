package org.example.exception;

public class StackOverflowException extends Exception
{

	public StackOverflowException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
