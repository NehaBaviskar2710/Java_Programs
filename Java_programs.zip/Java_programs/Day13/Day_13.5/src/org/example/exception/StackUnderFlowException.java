package org.example.exception;

public class StackUnderFlowException extends Exception
{

	public StackUnderFlowException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
