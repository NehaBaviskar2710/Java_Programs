package org.example.main;

public class Resources
{
	public static void main(String[] args)
	{
		System.out.println("Connect database");
		int num1 = 10;
		int num2 = 5;
		int result = num1/num2;
		System.out.println("Result:"+result);
		System.out.println("Disconnet Database");
	}
}