package org.example.main;

import java.util.Scanner;
public class Program
{
	public static void main(String[] args)
	{
		Scanner sc = null;
		
		sc = new Scanner(System.in);
		
		System.out.println("Num1:");
		int num1 = sc.nextInt();
		
		System.out.println("Num2:");
		int num2 = sc.nextInt();
		
		int result = num1/num2;
		System.out.println("Result:"+result);
		
		System.out.println("Closing resource");
		sc.close();
	}
}