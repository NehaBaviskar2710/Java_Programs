package org.example.main;

interface Collection
{
	void acceptRcord();
	
}