package org.example.main;

public class Generic 
{
	public static<T> void print(T obj)
	{
		System.out.println(obj);
	}
	public static void main(String[] args)
	{
		Generic.print(123);
		Generic.print(true);
		Generic.print(10.2f);
		Generic.print('A');
		Generic.print(1234554d);
		Generic.print("Good Morning");
		Generic.print(new Generic());
	}
}
