package org.example.main;

interface Printable
{
	int value = 111;
	
	void print();
}
class Test implements Printable
{
	@Override
	public void print()
	{
		System.out.println("Value:"+Printable.value);
	}
}
public class InterfaceProgram 
{
	public static void main(String[] args)
	{
		Printable p ;
		p = new Test();
		p.print();
	}
}
