package org.example.main;

public class WithoutGenerics 
{
	public static void print(Object object)
	{
		System.out.print(object);
	}
	public static void main(String[] args)
	{
		WithoutGenerics.print(123);
		WithoutGenerics.print(true);
		WithoutGenerics.print('A');
		WithoutGenerics.print(12345);
		WithoutGenerics.print(123.45f);
		WithoutGenerics.print("Good Morning");
		
		
	}
}
