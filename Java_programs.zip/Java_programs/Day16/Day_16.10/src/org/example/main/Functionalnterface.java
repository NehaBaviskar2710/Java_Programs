package org.example.main;

public class Functionalnterface {

}
